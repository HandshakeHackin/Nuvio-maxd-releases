#pragma once
#include <array>
#include <string>
#include <string_view>
namespace sx {
inline bool should_show_release_notes(std::string_view seen, std::string_view current) {
    return !current.empty() && seen != current;
}
inline constexpr std::array<const char*,6> release_note_items = {
    "Automatic subtitles now prefer a matching track inside the video file.",
    "Addon subtitles are used when the file has no matching track.",
    "Manual subtitle choices, including Off, stay selected.",
    "Cached addon subtitles keep their styling after seeking.",
    "Includes the playback, surround audio and subtitle improvements from 0.5.18.",
    "Reopen these update notes from Settings → What's new."
};
}
