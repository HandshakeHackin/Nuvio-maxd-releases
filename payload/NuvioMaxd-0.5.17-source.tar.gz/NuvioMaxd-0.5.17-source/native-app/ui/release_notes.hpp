#pragma once
#include <array>
#include <string>
#include <string_view>
namespace sx {
inline bool should_show_release_notes(std::string_view seen, std::string_view current) {
    return !current.empty() && seen != current;
}
inline constexpr std::array<const char*,6> release_note_items = {
    "Style your subtitles, with a live preview in Settings.",
    "Choose your D-pad and L1 / R1 seek intervals.",
    "Set how long the next-episode countdown lasts.",
    "Make menus easier to read with higher contrast and reduced motion.",
    "Improved playback diagnostics help investigate problems.",
    "See these update notes again from Settings → What's new."
};
}
