#pragma once
#include <array>
#include <string>
#include <string_view>
namespace sx {
inline bool should_show_release_notes(std::string_view seen, std::string_view current) {
    return !current.empty() && seen != current;
}
inline constexpr std::array<const char*,6> release_note_items = {
    "Updated audio timing and recovery after a seek or decoder failure.",
    "Surround PCM audio, with stereo fallback and a Settings toggle.",
    "Styled ASS and bitmap subtitles, including PGS tracks.",
    "More subtitle languages, with bundled CJK and Thai fonts.",
    "Additional HDR format checks and clearer output errors.",
    "Reusable packet storage and bounded audio buffering."
};
}
