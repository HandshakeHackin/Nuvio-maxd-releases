# Third-party code, tools and assets

Nuvio Max'd is licensed under the GNU General Public License v3.0 (see
`LICENSE`), as required by the GPL-licensed code it includes and links (the
FFmpeg build it uses is GPL-3.0-or-later). It is an unofficial port and is not
affiliated with or endorsed by Stremio.

This native adaptation incorporates [Sp9nky/unofficial-stremio-ps5-port](https://github.com/Sp9nky/unofficial-stremio-ps5-port), commit a4b12fb515a3044f073f4befba0dd90d8244eddd (GPL-3.0), including its UI and integrated playback engine. Nuvio account integration and the Nuvio Max'd interface and branding have been added.

## Code included in this repository

| Where | What | License |
| `gl/update_channel.cpp`, `update/helper.cpp` | Bundled helper handoff follows BlackBearReloaded's [ProsperoEden](https://github.com/blackbearreloaded/ProsperoEden/tree/868669fe63d44cf41ffe3412aeaac2527cff5f57/headless/update_check), commit `868669fe63d44cf41ffe3412aeaac2527cff5f57`, and the native app kit. The FFPFSC transaction is specific to Nuvio; it uses the documented public HTTP API of [ShadowMount+ 1.7](https://github.com/drakmor/ShadowMountPlus/blob/4cde42a2293756132735d8e4280eb71f089865ee/docs/api.md), rather than its private control protocol. | GPL-3.0-or-later |
| --- | --- | --- |
| `src/display_output.h`, `src/display_output.cpp`, `tests/display_output_host.cpp` | PS5 output-resolution selection and probe tests adapted from [LoZazaMastro/Stremio-Plus](https://github.com/LoZazaMastro/Stremio-Plus/tree/64d1bfb5b78b3c6a37e013973402f3239bee5df0), commit `64d1bfb5b78b3c6a37e013973402f3239bee5df0`; the VideoOut ABI follows BlackBearReloaded's ProsperoLight, with its attribution retained | GPL-3.0-or-later |
| `native/console_curl.c`, `native/console_curl.h` | libcurl support for PS5 native titles, from [ps5-native-app-boilerplate](https://github.com/blackbearreloaded/ps5-native-app-boilerplate) (BlackBearReloaded; its `gmtime_r` follows Howard Hinnant's public-domain `civil_from_days`) | GPL-3.0-or-later |
| `native/ps5-app.ld` | linker layout, from ps5-native-app-boilerplate's `tooling/native/ps5-pie.ld`, with unwind-table symbols added | GPL-3.0-or-later |
| `native/heap.c`, `native/posix_fixes.c`, `native/ps5_modules.c` | approach and parts adapted from the [Kodi port for PS5](https://github.com/VivaLaVent/kodi-ps5) (Team Kodi / VivaLaVent: `shims/native-app/heap_dmem.c`, `thread_stack.c`, `pipe_fallback.c`, `PS5ImeDialog.cpp`) | GPL-2.0-or-later |
| `native/dlmalloc.c` | Doug Lea's malloc 2.8.6 | MIT-0 |
| `third_party/hui/` | [ps5-homebrew-ui](https://github.com/blackbearreloaded/ps5-homebrew-ui) (BlackBearReloaded), the OpenGL interface toolkit: renderer, controller input, text and shape drawing, glyphs, PS5 display and pad code; vendored at commit `4bd9425` (see `third_party/hui/VERSION.txt`) with local texture updates, display-mode selection and optional refresh requests/readback. Its own notices are `third_party/hui/THIRD_PARTY_NOTICES.md`; the shape shader follows Inigo Quilez's published 2D distance functions (MIT); `stb_truetype` and `stb_image_write` (Sean Barrett, public domain / MIT) are in it and are used only by host tools, not linked into the app | GPL-3.0-or-later |
| `native/hui_runtime_shims.c` | process-level runtime shims for the OpenGL runtime, from ps5-homebrew-ui's `src/runtime/runtime_shims.c` (itself adapted from ps5-opengl's `native-app/runtime_shims.c`) | GPL-3.0-or-later |
| `third_party/qrcodegen.c`, `third_party/qrcodegen.h` | [Nayuki QR Code generator](https://github.com/nayuki/QR-Code-generator), C library; license embedded in both files | MIT |
| `third_party/json.hpp` | [nlohmann/json](https://github.com/nlohmann/json) 3.11.3 (Niels Lohmann) | MIT |
| `third_party/stb_image.h` | [stb_image](https://github.com/nothings/stb) 2.30 (Sean Barrett): loads the artwork and icons | MIT / public domain |
| `src/hwdec_ps5.cpp` (hardware video decoding), `native/stubs/videodec2.c` | ported from [Nuvio PS5](https://github.com/theghostonline/Nuvio-PS5) (`app/engine/media/src/evo_vdec_native.c`, Husam Osman, itself built on an open-source GPL-3.0 PS5 media player); the libSceVideodec2 structures and call sequence come from there and from [ProsperoLight](https://github.com/blackbearreloaded/ProsperoLight) (BlackBearReloaded) and [SharpProspero](https://github.com/SvenGDK/SharpProspero) (SvenGDK) | GPL-3.0-or-later |
| HEVC Main10 smaller-pipeline retry in `src/hwdec_ps5.cpp` | adapted from [EVO Player's native decoder](https://github.com/sainsaji/EVO-PLAYER-PS5/blob/21524a4a6effa65312be2026042e44a96efca4c6/projects/evoplayer/media/src/evo_vdec_native.c), commit `21524a4a6effa65312be2026042e44a96efca4c6` | GPL-3.0-or-later |
| `gl/hdr_output.cpp` (in-place HDR10 VideoOut transitions) | call sequence and VideoOut ABI adapted from [EVO Player's native AGC renderer](https://github.com/sainsaji/EVO-PLAYER-PS5/blob/9715f6ee9bf9b53461d6fdf9a2e11b4c48357783/projects/evoplayer/media/src/evo_agc_runtime.c), commit `9715f6ee9bf9b53461d6fdf9a2e11b4c48357783`; VideoOut type definitions credited there to SharpProspero (SvenGDK) | GPL-3.0-or-later |
| `gl/hdr_output.cpp`, `gl/hdr_compositor.cpp` (RGB HDR10 scanout token and channel layout) | [ProsperoLight's shared VideoOut format definitions](https://github.com/blackbearreloaded/ProsperoLight/blob/a6e56cf4e8e9e469d5bc5cc06ff71ad4ca16a6a9/include/ps5_videoout_formats.h), commit `a6e56cf4e8e9e469d5bc5cc06ff71ad4ca16a6a9`; its [validation notes](https://github.com/blackbearreloaded/ProsperoLight/blob/a6e56cf4e8e9e469d5bc5cc06ff71ad4ca16a6a9/docs/VALIDATION.md) record native HDR10 hardware acceptance | GPL-3.0-or-later |
| `src/netstream.cpp` (several connections for big files) | the approach and sizes of Nuvio PS5's `evo_parallel_io.c` | GPL-3.0-or-later |
| `gl/session_watch.cpp` (torrent stream set-up) | follows the behaviour of `createTorrent` in [stremio-video](https://github.com/Stremio/stremio-video) (Stremio) | MIT |

## Linked into the app (downloaded at build time, not included here)

The release `eboot.bin` statically links these. All come from the
[ps5-payload-sdk](https://github.com/ps5-payload-dev/sdk) and its
[PacBrew](https://github.com/ps5-payload-dev/pacbrew-repo) packages
(both GPL-3.0 for their own recipes and code); every library keeps its own
license:

| Component | License |
| --- | --- |
| ps5-payload-sdk `libc.a`, start-up code and system-module stubs | GPL-3.0-or-later; FreeBSD-derived parts BSD |
| ps5-native-app-boilerplate start-up code (`tooling/native/app_crt.cpp`) and the clean-room `sce_module/libc.prx` loader shim shipped with the app | GPL-3.0-or-later |
| [LLVM](https://llvm.org/) libc++, libc++abi, libunwind | Apache-2.0 WITH LLVM-exception |
| [ps5-opengl](https://github.com/blackbearreloaded/ps5-opengl) SDK (BlackBearReloaded), v1.0.0: OpenGL 4.6 on the PS5, with [Mesa](https://mesa3d.org/) and OpenGNM PSBC components. Downloaded at build time (checksum-verified); its license texts and notices are copied into the app (`licenses/ps5-opengl/`) | GPL-3.0-or-later; Mesa MIT; the other parts as stated in the SDK |
| [miniupnpc](https://github.com/miniupnp/miniupnp) (Thomas Bernard): the built-in torrent engine's port mapping | BSD-3-Clause |
| [dht](https://github.com/jech/dht) (Juliusz Chroboczek): the built-in torrent engine's DHT | MIT |
| [FFmpeg](https://ffmpeg.org/) (libavformat, libavcodec, libavutil, libswresample, libswscale), built with `--enable-gpl --enable-version3` | GPL-3.0-or-later |
| [x264](https://www.videolan.org/developers/x264.html) (pulled in by that FFmpeg build) | GPL-2.0-or-later |
| [libcurl](https://curl.se/) | curl license (MIT/X derivative) |
| [OpenSSL](https://www.openssl.org/) | Apache-2.0 |
| [libpsl](https://github.com/rockdaboot/libpsl) | MIT; Public Suffix List data MPL-2.0 |
| [libwebp](https://chromium.googlesource.com/webm/libwebp) and libsharpyuv (the posters' format) | BSD-3-Clause |
| [zlib](https://zlib.net/) | zlib |
| [zstd](https://github.com/facebook/zstd) | BSD-3-Clause (dual GPL-2.0) |
| [xz / liblzma](https://tukaani.org/xz/) | 0BSD / public domain |
| [bzip2](https://sourceware.org/bzip2/) | bzip2 license (BSD-style) |
| [GNU libiconv](https://www.gnu.org/software/libiconv/) | LGPL-2.1-or-later |
| [GNU FriBidi](https://github.com/fribidi/fribidi): right-to-left subtitles (Arabic, Hebrew) | LGPL-2.1-or-later |

## Build tools (downloaded at build time, not included here)

| What | License |
| --- | --- |
| [ps5-payload-sdk](https://github.com/ps5-payload-dev/sdk): compiler wrappers, headers, sysroot | GPL-3.0-or-later (FreeBSD headers BSD) |
| [LLVM/Clang/lld](https://llvm.org/) 18 | Apache-2.0 WITH LLVM-exception |
| [ps5-native-app-boilerplate](https://github.com/blackbearreloaded/ps5-native-app-boilerplate) (BlackBearReloaded): native-app converter, signer, asset validation; its converter and FSELF writer are derived from [SharpProspero](https://github.com/SvenGDK/SharpProspero) (SvenGDK) | GPL-3.0-or-later; GPL-3.0 |
| [MkPFS](https://github.com/PSBrew/MkPFS) (PSBrew): packs the `.ffpfsc` image | GPL-3.0 |
| [DirectXTex texconv](https://github.com/microsoft/DirectXTex) (Microsoft): converts the home-screen pictures | MIT |
| [librsvg](https://gitlab.gnome.org/GNOME/librsvg) `rsvg-convert`: renders the UI icons (`tools/make_icons.sh`) | LGPL-2.1-or-later |
| [ps5-homebrew-ui](https://github.com/blackbearreloaded/ps5-homebrew-ui): its `tools/fetch-opengl-sdk.sh` downloads the pinned ps5-opengl SDK | GPL-3.0-or-later |
| [Pillow](https://python-pillow.org/): draws the sample artwork for the screen-preview tool (`tools/preview/make_sample_art.py`) | MIT-CMU (HPND) |

## Assets in `app/`

| What | Source | License |
| --- | --- | --- |
| UI icons (`app/assets/icons_4k/`, made by `tools/make_icons.sh`) | [Stremio/stremio-icons](https://github.com/Stremio/stremio-icons) | MIT (as declared in its `package.json`) |
| Nuvio Max'd icon and menu mark (`app/sce_sys/icon0.png`, `app/assets/icons_4k/logo*.png`) | Original artwork prepared for this project with OpenAI image generation; released with this project. Nuvio identifies the external service, whose branding belongs to its owners. | GPL-3.0-or-later |
| Fonts (`app/fonts/`) | Noto Sans and Noto Emoji (Google) | SIL Open Font License 1.1 (`app/fonts/OFL.txt`) |
| Interface fonts (`app/fonts/Inter-*`, `app/fonts/Montserrat-Medium.ttf`) | Inter (The Inter Project Authors), Montserrat (The Montserrat Project Authors) | SIL Open Font License 1.1 (`app/fonts/Inter-LICENSE.txt`, `app/fonts/Montserrat-LICENSE.txt`) |
| Baked interface fonts (`third_party/hui/assets/fonts/*.huifont`, distance-field renderings made by the toolkit) | Inter, Montserrat, DejaVu Sans Mono (Bitstream, DejaVu), Press Start 2P, Patrick Hand | SIL Open Font License 1.1; Bitstream Vera license for DejaVu (texts beside the files) |
| Interface sounds (`app/sounds/glass/`) | the "glass" sound set of ps5-homebrew-ui (originally ProsperoEden, BlackBearReloaded), generated with ElevenLabs Sound Effects v2 for those projects and prepared by the toolkit's tools; played by the toolkit's mixer (`third_party/hui/src/audio`) | GPL-3.0-or-later, as stated in `third_party/hui/THIRD_PARTY_NOTICES.md` |
| Arabic font (`app/fonts/NotoNaskhArabicUI-*`) | Noto Naskh Arabic UI (Google), as shipped by [Nuvio PS5](https://github.com/theghostonline/Nuvio-PS5) | SIL Open Font License 1.1 (`app/fonts/NotoNaskhArabicUI-NOTICE.txt`) |
| `app/ca-bundle.crt` | Mozilla's CA certificate list, as distributed by curl | MPL-2.0 |

## License texts

`app/licenses/` holds the license text of every component above, with an
index (`app/licenses/README.txt`). The build copies that folder,
`LICENSE` and this file into the app, together with the notices of the toolkit and
of the OpenGL SDK, so they ship inside the `.ffpfsc`.

## Services and runtime

The app talks to Nuvio's public account and device-pairing services (`api.nuvio.tv`, `nuvio.tv/link`) and to configured addons. Metadata and streams belong to their owners. Cinemeta and OpenSubtitles are optional fallback addons. Streams play directly on the console using the integrated torrent engine or the stream's HTTP link. On the console it relies on
[ShadowMountPlus](https://github.com/drakmor/ShadowMountPlus) (drakmor),
[etaHEN](https://github.com/etaHEN/etaHEN) and
[kstuff](https://github.com/EchoStretch/kstuff); none of them is included.

"Stremio" and the Stremio logo are trademarks of their owner. They are used
here only to identify the service this unofficial client connects to.

This project is not affiliated with, endorsed by or connected to Sony
Interactive Entertainment. "PlayStation", "PS5" and "DualSense" are trademarks
of Sony Interactive Entertainment Inc., used only to say which console the
app runs on. No Sony code, SDK, keys or firmware files are included: the
system-module stubs and the `libc.prx` loader shim are independently written
(ps5-payload-sdk, ps5-native-app-boilerplate).

## Episode timings

Intro, recap and credit timings come from [IntroDB](https://introdb.app/) through
its HTTPS API, following the episode mapping used by Nuvio's
`js/data/repository/skipIntroRepository.js`. Requests contain only the IMDb title
ID and season/episode numbers (or a movie flag); no account tokens, playable
URLs or provider headers are sent. Coverage and release timing accuracy vary.
The native implementation validates timings and preserves known post-credit
scenes before automatic transitions.
