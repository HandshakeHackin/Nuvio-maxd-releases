// SPDX-License-Identifier: GPL-3.0-or-later
#include "session.hpp"
namespace sx {
void Session::update_menu() {
    using Phase=AppUpdate::Phase;
    const auto s=updater_.status();
    if(s.phase==Phase::available) {
        open_dropdown("Nuvio Max'd "+s.release.version,{"Download update","Later"},0,[this](int i){if(i==0){updater_.download(base_dir_,data_dir_);update_menu();}});
        dropdown.message=std::to_string((s.release.size+(1<<20)-1)>>20)+" MB FFPFSC. Matching source is included in the public release.\n\n"+s.release.notes.substr(0,350);
    } else if(s.phase==Phase::ready) {
        open_dropdown("Update ready",{"Install and close Nuvio Max'd","Cancel update"},0,[this](int i){if(i==0){updater_.install();say("Closing Nuvio Max'd after the helper is ready",8);}else updater_.cancel();});
        dropdown.message="The verified image is staged. Nuvio Max'd will close, retain a backup and request a ShadowMount+ rescan. Reopen it after the update notification. Your saved data stays in place.";
    } else if(s.phase==Phase::checking || s.phase==Phase::downloading || s.phase==Phase::staging) {
        open_dropdown("App updates",{"Cancel"},0,[this](int){updater_.cancel();});
        dropdown.message=s.message;dropdown.progress=s.progress;
    } else {
        open_dropdown("App updates",{"Check for updates","Close"},0,[this](int i){if(i==0){updater_.check();update_menu();}});
        dropdown.message=s.message.empty()?"Nuvio Max'd 0.5.14 (experimental). Updates use the public download feed; no GitHub login is needed.":s.message;
    }
    update_dialog_=true;
}
void Session::update_status() {
    const auto s=updater_.status();
    if(s.phase==AppUpdate::Phase::closing) {exit_=true;return;}
    if(s.phase!=update_phase_) {
        update_phase_=s.phase;refresh_settings();
        if(update_dialog_ && dropdown_open) update_menu();
        else if(s.phase==AppUpdate::Phase::error) say(s.message,9,true);
    } else if(update_dialog_ && dropdown_open && s.progress>=0) {
        dropdown.progress=s.progress;dropdown.message=s.message;
    }
}
}
