// Host-only declarations for the pinned SDK's default render profile.
// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
#define PS5_OPENGL_NATIVE_WIDTH 1920
#define PS5_OPENGL_NATIVE_HEIGHT 1080
#define PS5_OPENGL_NATIVE_FPS 60
