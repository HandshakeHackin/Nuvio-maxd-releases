Nuvio Max'd - license notices

Nuvio Max'd is maintained by HandshakeHackin under GNU GPL v3.0.
Project/source: https://github.com/HandshakeHackin/Nuvio-maxd-releases
Derived from Sp9nky's unofficial-stremio-ps5-port and the credited Nuvio/native
app work below. See CREDITS.txt and LICENSE at the app root.
It contains or links the components below; each keeps its own license, whose
text is in this folder. THIRD_PARTY.md lists where each one is used.

Component                                  License                         File
-----------------------------------------  ------------------------------  ---------------------
ps5-native-app-boilerplate (BlackBear-     GPL-3.0-or-later                ../LICENSE
  Reloaded), ps5-payload-sdk, PacBrew,
  FFmpeg build, MkPFS, SharpProspero
ps5-payload-sdk libc (FreeBSD parts)       BSD                             FreeBSD.txt
Kodi port for PS5 (Team Kodi, VivaLaVent)  GPL-2.0-or-later                GPL-2.0.txt
Nuvio PS5 (Husam Osman): hardware decoder  GPL-3.0-or-later                ../LICENSE
x264                                       GPL-2.0-or-later                GPL-2.0.txt
FFmpeg                                     GPL-3.0-or-later (this build)   FFmpeg.txt, ../LICENSE
LLVM libc++, libc++abi, libunwind          Apache-2.0 WITH LLVM-exception  LLVM.txt
ps5-homebrew-ui (BlackBearReloaded):       GPL-3.0-or-later                ps5-homebrew-ui/LICENSE,
  the UI toolkit (vendored)                                                  ps5-homebrew-ui/THIRD_PARTY_NOTICES.md
ps5-opengl SDK (BlackBearReloaded), with   GPL-3.0-or-later; Mesa MIT;     ps5-opengl/ (the SDK's own license
  Mesa and OpenGNM PSBC                    other parts as in the SDK       texts and notices)
Inigo Quilez's 2D distance functions        MIT                             (in the toolkit's notices)
libxml2                                    MIT                             libxml2.txt
libcurl                                    curl                            curl.txt
OpenSSL                                    Apache-2.0                      OpenSSL.txt
libpsl                                     MIT                             libpsl.txt
Public Suffix List data, ca-bundle.crt     MPL-2.0                         MPL-2.0.txt
libwebp, libsharpyuv                       BSD-3-Clause (+ patent grant)   libwebp.txt, libwebp-PATENTS.txt
zlib                                       zlib                            zlib.txt
zstd                                       BSD-3-Clause                    zstd.txt
xz / liblzma                               0BSD                            xz.txt, xz-0BSD.txt
bzip2                                      bzip2 License                   bzip2.txt
GNU libiconv                               LGPL-2.1-or-later               LGPL-2.1.txt
GNU FriBidi                                LGPL-2.1-or-later               FriBidi.txt
dlmalloc (Doug Lea)                        MIT-0                           dlmalloc.txt
nlohmann/json (Niels Lohmann)              MIT                             nlohmann-json.txt
dht (Juliusz Chroboczek)                   MIT                             dht.txt
miniupnpc (Thomas Bernard)                 BSD-3-Clause                    miniupnpc.txt
stb_image (Sean Barrett)                   MIT / public domain             stb_image.txt
Stremio icons, stremio-video               MIT                             Stremio-MIT.txt
dashboard-icons (logo)                     Apache-2.0                      dashboard-icons.txt
Noto Sans, Noto Emoji (Google)             SIL OFL 1.1                     ../fonts/OFL.txt
Inter, Montserrat (interface fonts)         SIL OFL 1.1                     ../fonts/Inter-LICENSE.txt,
                                                                           ../fonts/Montserrat-LICENSE.txt
DejaVu Sans Mono (baked interface font)      Bitstream Vera license          ../hui-fonts/DejaVu-LICENSE.txt
Noto Naskh Arabic UI (Google)              SIL OFL 1.1                     ../fonts/NotoNaskhArabicUI-NOTICE.txt

"Stremio" and the Stremio logo are trademarks of their owner, used only to
identify the service this unofficial client connects to. This app is not
affiliated with or endorsed by Stremio or Sony Interactive Entertainment.
"PlayStation", "PS5" and "DualSense" are trademarks of Sony Interactive
Entertainment Inc. No Sony code, SDK, keys or firmware files are included. The home-screen
pictures are this project's own artwork (the interface's violet light and the
Stremio logo).

Subtitle rendering dependencies added in 0.5.18:
libass (libass contributors)               ISC                             libass.txt
HarfBuzz (HarfBuzz contributors)           MIT-style                       HarfBuzz.txt
FreeType (FreeType Project)                FreeType License                FreeType.txt
fontconfig (fontconfig contributors)       MIT-style                       fontconfig.txt
Expat (Expat contributors)                 MIT                             expat.txt
libpng (PNG Reference Library authors)     PNG Reference Library License   libpng.txt
Noto Sans CJK SC / Noto Sans Thai           SIL OFL 1.1                     ../fonts/NotoSansCJK-LICENSE.txt,
                                                                           ../fonts/NotoSansThai-LICENSE.txt

ProsperoTube playback adaptation (GPL-3.0-or-later)
Copyright (C) 2026 BlackBearReloaded.
Source: https://github.com/blackbearreloaded/ProsperoTube
Reviewed commit: aa7eaec9b61b53f0f50cc35c6740858ca149db60.
The low-frame-rate scheduler in gl/tube_frame_pacing.h is adapted from
native/tube_frame_pacing.h at that commit. HDR switching and GPU lifetime
safeguards follow the in-place VideoOut and frame-retirement approach,
adapted to Nuvio's OpenGL renderer. The matching source archive contains
the scheduler and adaptations; the GPL license is included in this package.

NuvioTVLauncher feature inspiration (GPL-3.0): native C++ start-page and Live TV
controls. Credits and reviewed source: nuvio-tv-launcher/NOTICE.txt, UPSTREAM.json.
