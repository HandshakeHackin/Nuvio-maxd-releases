// Network input for the player: FFmpeg reads HTTP(S) through libcurl.
//
// FFmpeg's own HTTP client never got a byte from the streaming server on the
// PS5 (it opened, waited and gave up), while libcurl talks to the same server
// fine. So every http(s) URL the player opens -- the stream itself and, for
// HLS, the playlists and segments -- goes through NetStream instead.
#pragma once

#include <atomic>
#include <condition_variable>
#include <cstdio>
#include <cstdint>
#include <mutex>
#include <string>
#include <thread>
#include <vector>

struct AVIOContext;
struct AVFormatContext;
struct AVDictionary;

// Big files (debrid links, direct URLs) can be fetched by several connections
// at once ("parallel"): one connection is often what limits the speed, not
// the line (Wi-Fi caps a single stream, debrid hosts cap each connection).
// The idea and sizes come from Nuvio PS5's evo_parallel_io.c.
class NetStream {
public:
	NetStream(const std::string& url, const std::vector<std::string>& headers, const std::atomic<bool>* abort,
	          bool parallel = false);
	~NetStream();

	// Starts downloading and waits for the response headers. False on error
	// (see error()).
	bool start();
	const std::string& error() const { return error_; }  // after start(), same thread
	std::string effective_url(); // resolved URL, for relative adaptive playlists
	std::string failure();  // any time: why downloading stopped, if it did
	int64_t size() const { return size_; }  // -1 when unknown

	// The first bytes at the current position, without consuming them
	// (fewer at the end of the file or on error).
	std::string peek(size_t n);
	static NetStream* of(AVIOContext* pb);

	// AVIOContext callbacks: FFmpeg error codes on failure.
	int read(uint8_t* buf, int n);
	int64_t seek(int64_t offset, int whence);

	// An AVIOContext reading this stream; free with close_avio().
	// Where big streams keep their read-ahead (the app's storage).
	static void set_cache_dir(const std::string& dir);

	static AVIOContext* open_avio(const std::string& url, const std::vector<std::string>& headers,
	                              const std::atomic<bool>* abort, std::string* error, bool parallel = false,
	                              const std::atomic<bool>* read_interrupt = nullptr);
	static bool is_ours(AVIOContext* pb);
	// Interrupt a blocked reader for a seek without cancelling its downloader.
	static void set_read_interrupt(AVIOContext* pb, const std::atomic<bool>* pending);
	static void close_avio(AVIOContext** pb);

	// AVFormatContext.io_open / io_close2 for the files a demuxer opens
	// itself (HLS playlists and segments). opaque must point at the
	// player's IoHooks.
	struct IoHooks {
		const std::atomic<bool>* read_interrupt = nullptr;
		std::vector<std::string> headers;
		const std::atomic<bool>* abort = nullptr;
		int (*default_open)(AVFormatContext*, AVIOContext**, const char*, int, AVDictionary**) = nullptr;
		int (*default_close)(AVFormatContext*, AVIOContext*) = nullptr;
	};
	static void install(AVFormatContext* fmt, IoHooks* hooks);

private:
	void run();
	bool transfer(int64_t from, int gen);
	bool stopped() const;

	// Parallel mode: chunks of the file in a window ahead of the reader.
	struct Chunk {
		int64_t index = -1;  // which chunk this slot holds
		int state = 0;       // 0 empty, 1 downloading, 2 ready
		int attempts = 0;
		double retry_at = 0;
		int64_t len = 0;
		std::vector<uint8_t> data;  // when the read-ahead is in memory
	};
	void start_parallel();
	void worker();
	int read_parallel(std::unique_lock<std::mutex>& lock, uint8_t* buf, int n);
	void drop_disk_cache(const char* why);
	void log_speed(int64_t bytes);
	bool parallel_wanted_ = false, parallel_ = false;
	int window_ = 32;           // chunks held ahead of the reader
	FILE* cache_ = nullptr;     // the read-ahead on storage (slot i at i x 4 MB)
	std::string cache_path_;
	double speed_at_ = 0;
	int64_t speed_bytes_ = 0;
	std::string final_url_;  // after redirects, so each chunk goes straight there
	void* cur_curl_ = nullptr;  // the single download's handle (for its final URL)
	std::vector<Chunk> chunks_;
	std::vector<std::thread> workers_;
	int64_t window_base_ = 0;  // first chunk of the window
	int64_t par_bytes_ = 0;
	double par_started_ = 0;
	int consecutive_failures_ = 0;
	double retry_all_at_ = 0;  // shared cooldown: do not rush through fresh chunks

	static size_t on_header(char* data, size_t size, size_t n, void* self);
	static size_t on_data(char* data, size_t size, size_t n, void* self);
	static int on_progress(void* self, int64_t, int64_t, int64_t, int64_t);

	std::string url_;
	std::vector<std::string> headers_;
	const std::atomic<bool>* abort_;
	const std::atomic<bool>* read_interrupt_ = nullptr;

	std::mutex m_;
	std::condition_variable cv_;
	std::thread thread_;
	bool stop_ = false;

	// Requests to the download thread: (re)start at req_pos_ when gen_ moves.
	int gen_ = 0, started_gen_ = -1;
	int64_t req_pos_ = 0;

	// Downloaded, not yet read: buf_[head_..] holds bytes from pos_ on.
	std::vector<uint8_t> buf_;
	size_t head_ = 0;
	int64_t pos_ = 0;
	bool eof_ = false;
	bool headers_done_ = false;
	long status_ = 0;
	int64_t size_ = -1;
	std::string error_;
	int64_t discard_ = 0;  // bytes still to drop before buf_ (short forward seeks, or a server that ignored Range)
	bool header_ok_ = false;
	int64_t range_from_ = 0;  // where the running transfer was asked to start
	int cur_gen_ = 0;      // generation of the running transfer (for the callbacks)
};
