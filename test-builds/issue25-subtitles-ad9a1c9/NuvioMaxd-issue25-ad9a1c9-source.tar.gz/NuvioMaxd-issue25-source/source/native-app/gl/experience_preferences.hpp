#pragma once
#include "../ui/i18n.hpp"
#include "../ui/subtitle_style.hpp"
#include "json.hpp"
#include "install_source.hpp"
#include <algorithm>
#include <cmath>
#include <string>
namespace sx {
struct ExperiencePreferences {
    std::string ui_language="en"; // local app preference, applied on next launch
    std::string trailer_language; // empty follows audio, then subtitle language
    std::string seen_release;
    std::string install_source; // user-selected, local only; empty means not asked yet
    SubtitleStyle subtitle_style;
    int seek_seconds = 10, shoulder_seek_seconds = 60, next_episode_seconds = 10;
    int audio_gain_percent=100, audio_delay_ms=0, subtitle_delay_ms=0;
    bool surround_audio = false;
    bool chapter_skip_segments=true;
    bool subtitle_auto_sync=false;
    int night_mode=0, lfe_mix_percent=50;
    bool console_light_sync = true;
    std::string audio_output_mode="pcm";
    bool reduced_motion = false, high_contrast = false;
};
inline int preference_int(const nlohmann::json& j, const char* key, int fallback, int lo, int hi) {
    const auto i=j.find(key);
    if(i==j.end() || !i->is_number()) return fallback;
    const double v=i->get<double>();
    return std::isfinite(v) ? int(std::clamp(v,double(lo),double(hi))) : fallback;
}
inline void load_experience(const nlohmann::json& j, ExperiencePreferences& p) {
    const auto ui_language=j.find("ui_language");
    p.ui_language=ui_language!=j.end()&&ui_language->is_string()?i18n::normalize_code(ui_language->get<std::string>()):"en";
    if(j.contains("trailer_language") && j["trailer_language"].is_string()) {
        const auto value=j["trailer_language"].get<std::string>();
        if(value.empty() || (value.size()==2 && value.find_first_not_of("abcdefghijklmnopqrstuvwxyz")==std::string::npos))p.trailer_language=value;
    }
    if(j.contains("install_source") && j["install_source"].is_string()) {
        const auto source=j["install_source"].get<std::string>();
        if(valid_install_source(source)) p.install_source=source;
    }
    if(j.contains("seen_release") && j["seen_release"].is_string()) {
        const auto value=j["seen_release"].get<std::string>(); if(value.size()<=40) p.seen_release=value;
    }
    if(j.contains("audio_output_mode") && j["audio_output_mode"].is_string()) {
        const auto mode=j["audio_output_mode"].get<std::string>();
        if(mode=="pcm" || mode=="auto" || mode=="bitstream")p.audio_output_mode=mode;
    }
    if(j.contains("surround_audio") && j["surround_audio"].is_boolean()) p.surround_audio=j["surround_audio"];
    if(j.contains("console_light_sync") && j["console_light_sync"].is_boolean()) p.console_light_sync=j["console_light_sync"];
    if(j.contains("chapter_skip_segments") && j["chapter_skip_segments"].is_boolean())p.chapter_skip_segments=j["chapter_skip_segments"];
    if(j.contains("subtitle_auto_sync") && j["subtitle_auto_sync"].is_boolean())p.subtitle_auto_sync=j["subtitle_auto_sync"];
    p.night_mode=preference_int(j,"night_mode",0,0,3);
    p.lfe_mix_percent=preference_int(j,"lfe_mix_percent",50,0,100);
    p.audio_gain_percent=preference_int(j,"audio_gain_percent",100,50,300);
    p.audio_delay_ms=preference_int(j,"audio_delay_ms",0,-2000,2000);
    p.subtitle_delay_ms=preference_int(j,"subtitle_delay_ms",0,-10000,10000);
    p.subtitle_style.font=preference_int(j,"subtitle_font",1,0,2);
    p.subtitle_style.colour=preference_int(j,"subtitle_colour",0,0,2);
    p.subtitle_style.effect=preference_int(j,"subtitle_effect",1,0,2);
    p.subtitle_style.background=preference_int(j,"subtitle_background",0,0,100);
    p.seek_seconds=preference_int(j,"seek_seconds",10,5,60);
    p.shoulder_seek_seconds=preference_int(j,"shoulder_seek_seconds",60,5,300);
    p.next_episode_seconds=preference_int(j,"next_episode_seconds",10,5,120);
    if(j.contains("reduced_motion") && j["reduced_motion"].is_boolean()) p.reduced_motion=j["reduced_motion"];
    if(j.contains("high_contrast") && j["high_contrast"].is_boolean()) p.high_contrast=j["high_contrast"];
}
inline void save_experience(nlohmann::json& j, const ExperiencePreferences& p) {
    j["ui_language"]=i18n::normalize_code(p.ui_language);
    j["subtitle_auto_sync"]=p.subtitle_auto_sync;
    j["trailer_language"]=p.trailer_language;
    j["chapter_skip_segments"]=p.chapter_skip_segments;
    j["night_mode"]=p.night_mode; j["lfe_mix_percent"]=p.lfe_mix_percent;
    j["audio_gain_percent"]=p.audio_gain_percent;
    j["audio_delay_ms"]=p.audio_delay_ms;
    j["subtitle_delay_ms"]=p.subtitle_delay_ms;
    j["console_light_sync"]=p.console_light_sync;
    j["surround_audio"]=p.surround_audio;
    j["audio_output_mode"]=p.audio_output_mode;
    j["seen_release"]=p.seen_release;
    j["install_source"]=p.install_source;
    j["subtitle_font"]=p.subtitle_style.font; j["subtitle_colour"]=p.subtitle_style.colour;
    j["subtitle_effect"]=p.subtitle_style.effect; j["subtitle_background"]=p.subtitle_style.background;
    j["seek_seconds"]=p.seek_seconds; j["shoulder_seek_seconds"]=p.shoulder_seek_seconds;
    j["next_episode_seconds"]=p.next_episode_seconds;
    j["reduced_motion"]=p.reduced_motion; j["high_contrast"]=p.high_contrast;
}
}
