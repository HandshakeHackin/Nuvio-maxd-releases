// Exercise the production stream reader and worker scheduler over local HTTP.
// SPDX-License-Identifier: GPL-3.0-or-later
#include "netstream.h"
#include "http_credentials.hpp"
#include "http.h"
#include "util.h"
#include <curl/curl.h>
#include <atomic>
#include <iostream>
#include <thread>
#include <chrono>

static std::atomic<int> faults{0};
static std::atomic<bool> rapid{false}, release_request{false};
static std::atomic<bool> hold_next_init{false}, request_waiting{false};
extern "C" CURL* __real_curl_easy_init();
extern "C" CURL* __wrap_curl_easy_init() {
    // Newer static libcurl also creates private admin handles during the first
    // perform. Arm after the first read, so only the requested reconnect pauses.
    if(hold_next_init.exchange(false)) {
        request_waiting=true;
        while(!release_request)std::this_thread::sleep_for(std::chrono::milliseconds(1));
    }
    return __real_curl_easy_init();
}
extern "C" CURLcode __real_curl_easy_perform(CURL*);
extern "C" CURLcode __wrap_curl_easy_perform(CURL* c) {
    char* url = nullptr; curl_easy_getinfo(c, CURLINFO_EFFECTIVE_URL, &url);
    if (url && std::string(url).find("/dns-single") != std::string::npos) {
        ++faults; return CURLE_COULDNT_RESOLVE_HOST;
    }
    if (url && std::string(url).find("/dns-parallel") != std::string::npos && ++faults > 1)
        return CURLE_COULDNT_RESOLVE_HOST;
    return __real_curl_easy_perform(c);
}
int main(int argc, char** argv) {
    if (argc != 4) return 2;
    http_init(""); NetStream::set_cache_dir(std::string(argv[2]) == "seek" ? "" : argv[3]);
    std::atomic<bool> cancel{false};
    std::vector<std::string> headers;
    if(std::string(argv[2]).starts_with("media-"))headers={"X-Emby-Authorization: MediaBrowser Token=\"fixture-only\"", "X-Maxd-Credential-Origin: "+(std::string(argv[2])=="media-foreign"?std::string("http://foreign.invalid"):http_credentials::origin(argv[1]))};
    NetStream stream(argv[1], headers, &cancel, !std::string(argv[2]).starts_with("media-") && std::string(argv[2]) != "single" && std::string(argv[2]) != "rapid-single");
    rapid=std::string(argv[2])=="rapid-single";
    json result; result["started"] = stream.start();
    if (result["started"] == true) {
        uint8_t bytes[32]{}; int n = stream.read(bytes, sizeof bytes);
        result["read"] = n;
        if (n == 32) {
            bool correct = true; for (int i = 0; i < 32; ++i) correct &= bytes[i] == uint8_t(i);
            result["correct"] = correct;
            if(rapid) {
                hold_next_init=true;
                stream.seek(0,SEEK_SET);
                const auto until=std::chrono::steady_clock::now()+std::chrono::seconds(3);
                while(!request_waiting && std::chrono::steady_clock::now()<until)std::this_thread::sleep_for(std::chrono::milliseconds(1));
                const bool pending=request_waiting;
                stream.seek(53,SEEK_SET);release_request=true;
                n=stream.read(bytes,sizeof bytes);correct=pending && n==32;
                for(int i=0;i<32;++i)correct &= bytes[i]==uint8_t(53+i);
                result["seek_correct"]=correct;
            }
            if (std::string(argv[2]) == "seek") {
                const int64_t position = (180ll << 20) + 19;
                result["seek"] = stream.seek(position, SEEK_SET);
                n = stream.read(bytes, sizeof bytes);
                correct = n == 32;
                for (int i = 0; i < 32; ++i) correct &= bytes[i] == uint8_t(position + i);
                result["seek_correct"] = correct;
            }
        }
    }
    result["error"] = stream.failure(); result["fault_calls"] = faults.load();
    std::cout << result.dump() << std::endl;
}
