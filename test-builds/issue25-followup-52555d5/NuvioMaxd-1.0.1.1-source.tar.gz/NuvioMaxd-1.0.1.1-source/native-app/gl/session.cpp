#include "../ui/i18n.hpp"
#include "start_page.hpp"
#include "../src/subtitle_size.hpp"
// The session's core: setup, the account, addons, the library, settings, the
// pop-ups and the artwork. The Board, Discover and Library are session_browse.cpp,
// a title's page is session_detail.cpp.

#include "session.hpp"
#include "tracking.h"
#include "release_notes.hpp"
#include "settings_navigation.hpp"
#include "i18n.hpp"
#include "build_integrity_text.hpp"

#include "http.h"
#include "providers.h"
#include "display_output.h"
#include "nuvio_account.h"
#include "qrcodegen.h"
#include "netstream.h"
#include "torrent/engine.h"

#include <algorithm>
#include <cctype>
#include <chrono>
#include <cstdlib>

namespace sx
{

namespace
{

constexpr std::size_t kTextureBudget = 640u << 20; // bytes of artwork kept on the GPU

enum SettingIndex
{
    kAccount,
    kProfiles,
    kTracking,
    kLibrarySource,
    kConnectedServices,
    kTorrents,
    kTorrentOptions,
    kServer,
    kDisplay,
    kRefresh,
    kHdr,
    kPlaybackEngine,
    kSubLangs,
    kAutoSubs,
    kSubSize,
    kSubFont,
    kSubColour,
    kSubEffect,
    kSubBackground,
    kSeek,
    kShoulderSeek,
    kCountdown,
    kReducedMotion,
    kHighContrast,
    kDiagnostics,
    kReleaseNotes,
    kAudioMode,
    kAudioOutput,
    kAudioLangs,
    kAutoplay,
    kSkipSegments,
    kUiSounds,
    kCalmBackgrounds,
    kAddAddon,
    kReload,
    kDonation,
    kInstallSource,
    kUpdates,
    kExit,
    kConsoleLights,
    kReadAhead,
    kMetadataCredits,
    kAudioGain,
    kAudioDelay,
    kSubtitleDelay,
    kSubtitleAutoSync,
    kTrailerLanguage,
    kChapterSkip,
    kNightMode,
    kLfeMix,
    kMediaServers,
    kRemoteButtons,
    kSourceOptions,
    kSportsEnable,kSportsOpen,kSportsRegion,kSportsBrowse,kSportsFollowing,kSportsScores,kSportsChannels,kSportsClock,
    kUiLanguage,kTvdb,kConfigBackup,kAgeRatingCountry,kBuildIntegrity,kStartPage,
    kFreeTv,kFreeTvCountry,kFreeTvOpen,kUnifiedTv,
    kTopNavigation,
    kLiveRefresh,
    kSettingCount
};

std::string size_label(const std::string &s)
{
    return i18n::tr(subtitle_size::labels[subtitle_size::index(s)]);
}

// The first letter of a name (one UTF-8 character): an addon's mark when it has no logo.
std::string first_letter(const std::string &name)
{
    std::size_t len = name.empty() ? 0 : 1;
    while (len < name.size() && (static_cast<unsigned char>(name[len]) & 0xC0) == 0x80)
        ++len;
    return name.substr(0, len);
}

std::uint32_t colour_for(const std::string &name)
{
    static const std::uint32_t palette[] = {0x7b5bf5, 0x3b82f6, 0x0ea5a4, 0xe0568a, 0xe08a3c, 0x6d6ae0};
    return palette[fnv1a(name) % (sizeof(palette) / sizeof(palette[0]))];
}

} // namespace

Item item_from_meta_json(const json &j)
{
    Item it;
    it.id = jstr(j, "id", jstr(j, "imdb_id"));
    it.type = jstr(j, "type");
    it.name = jstr(j, "name");
    it.poster = jstr(j, "poster");
    it.background = jstr(j, "background");
    it.logo = jstr(j, "logo");
    it.description = jstr(j, "description");
    it.release_info = jstr(j, "releaseInfo", jstr(j, "year"));
    it.runtime = jstr(j, "runtime");
    it.imdb_rating = jstr(j, "imdbRating");
    const json &g = jobj(j, "genres");
    if (g.is_array())
        for (const auto &v : g)
            if (v.is_string())
                it.genres.push_back(v.get<std::string>());
    return it;
}

// ---------------------------------------------------------------------------
// Setup

bool Session::init(const std::string &base_dir, const std::string &data_dir, hui::gfx::Renderer *renderer)
{
    player_.subtitle_renderer().configure(base_dir+"/fonts");
    base_dir_ = base_dir;
    data_dir_ = data_dir;
    profile_dir_ = data_dir + "/guest";
    make_dirs(profile_dir_);
    renderer_ = renderer;
    make_dirs(data_dir_);
    log_open(data_dir_ + "/log.txt");
    dlog("app: Nuvio Max'd %s (native)", nuvio_update::current_version);
    http_init(base_dir_ + "/ca-bundle.crt");
    g_tasks.start(6);
    provider_tasks_.start(2);
    if (!providers::initialize(base_dir_ + "/providers/runtime.js"))
        dlog("providers: runtime unavailable");
    if (!providers::configure(base_dir_ + "/providers/applications.json"))
        dlog("providers: metadata configuration unavailable");
    boot_start_ = now_seconds();
    media_reporter_=std::make_unique<media_server::Reporter>();
    tex_.private_image=[state=media_art_](const std::string& uri,const std::atomic<bool>* cancel){
        const auto at=uri.find(':',10); HttpResponse failure;failure.error=sx::i18n::tr("Media server image unavailable");
        if(at==std::string::npos)return failure;
        const auto id=uri.substr(10,at-10),item=uri.substr(at+1);
        media_server::Connection c;{std::lock_guard<std::mutex> l(state->mutex);for(const auto& a:state->accounts)if(a.id==id)c=a;}
        return c.valid()?media_server::image(c,item,cancel):failure;
    };
    tex_.init(data_dir_ + "/art", renderer_, 6);
    // The app's storage holds the read-ahead: the built-in torrent engine's 6 GB
    // rolling cache, and up to 6 GB for a stream from a server or a direct link.
    bt::Engine::get().configure(data_dir_, 6ll << 30);
    NetStream::set_cache_dir(data_dir_);

    load_prefs();
    integrity_start();
    bt::Engine::get().set_cache_bytes(int64_t(prefs_.torrent_cache_gb)<<30);
    bt::Engine::get().set_enabled(prefs_.builtin_torrents);
    release_notes_version=nuvio_update::current_version;
    release_notes_open=should_show_release_notes(prefs_.seen_release,release_notes_version);
    if (!nuvio_account_init(base_dir_ + "/account-config.json", data_dir_))
        say(sx::i18n::tr("Could not load Nuvio account configuration"), 8.0, true);
    prefs_.auth_key = nuvio_profile_key();
    debrid::load(profile_dir_ + "/connected-services.json", services_);
    const auto account_user = nuvio_account_user_id();
    if ((!services_.torbox.sync_owner.empty() && services_.torbox.sync_owner != account_user) ||
        (!services_.premiumize.sync_owner.empty() && services_.premiumize.sync_owner != account_user) ||
        (!services_.animeskip.sync_owner.empty() && services_.animeskip.sync_owner != account_user)) {
        services_.clear_synced(); debrid::save(profile_dir_ + "/connected-services.json", services_);
    }
    prepared_->configure(services_);
    if (!signed_in()) {
        // Legacy guest data has no account owner. Claim it once so a future
        // account sign-in cannot absorb a different guest's local history.
        json marker, old_watch, old_prefs, existing;
        load_json(data_dir_ + "/watch-sync.json", old_watch);
        if (!load_json(data_dir_ + "/legacy-profile-owner.json", marker) && jstr(old_watch, "owner").empty()) {
            bool copied = true;
            for (const auto* file : {"progress.json", "connected-services.json"}) {
                json old;
                if (!load_json(profile_dir_ + "/" + file, existing) && load_json(data_dir_ + "/" + file, old))
                    copied = save_json(profile_dir_ + "/" + file, old) && copied;
            }
            if (!load_json(profile_dir_ + "/profile-settings.json", existing) && load_json(data_dir_ + "/settings.json", old_prefs))
                copied = save_json(profile_dir_ + "/profile-settings.json", old_prefs) && copied;
            if (copied) save_json(data_dir_ + "/legacy-profile-owner.json", json{{"owner", "guest"}});
        }
        load_profile_settings(); load_progress();
    }
    clock = format_clock();
    board.status = sx::i18n::tr("Loading your catalogs...");
    refresh_settings();
    refresh_library();
    refresh_addons();
    profile_ready_ = !signed_in();
    start_page_apply();
    if (signed_in()) {
        board.status = sx::i18n::tr("Choose your Nuvio profile to load your catalogs and history.");
        profile_prompt_pending_ = true;
    } else load_addons();
    if (!signed_in() && !prefs_.onboarding_done) {
        if(release_notes_open || prefs_.install_source.empty()) login_after_notes_=true;
        else login_start();
    }
    return true;
}

void Session::shutdown()
{
    search_keyboard_cancel();
    ime_.cancel();text_done_=nullptr;
    if(integrity_cancel_)*integrity_cancel_=true;
    person_leave();*cast_cancel_=true;
    sports_reset();
    profile_pin_cancel();
    if (device_cancel_) *device_cancel_ = true;
    prepared_->shutdown();
    updater_.shutdown();
    if (watching)
        watch_stop(false);
    player_.close();
    torrent_reset();
    media_reset();
    media_reporter_.reset();
    bt::Engine::get().shutdown();
    *d_cancel_ = true;
    *d_stream_cancel_ = true;
    if (w_episode_cancel_) *w_episode_cancel_ = true;
    if(live_cancel_)*live_cancel_=true;
    if(live_usb_cancel_)*live_usb_cancel_=true;
    if(live_guide_cancel_)*live_guide_cancel_=true;
    if(series_updates_cancel_)*series_updates_cancel_=true;
    if(iptv_cancel_)*iptv_cancel_=true;
    if(iptv_probe_cancel_)*iptv_probe_cancel_=true;
    provider_tasks_.stop();
    g_tasks.stop();
    tex_.shutdown();
    save_progress();
}

// ---------------------------------------------------------------------------
// Persistence

void Session::load_prefs()
{
    json j;
    if (load_json(data_dir_ + "/settings.json", j))
    {
        load_experience(j, prefs_);
        i18n::set_language(prefs_.ui_language);
        prefs_.source_preferences=source_policy::load(j);
        prefs_.remote_bindings=load_remote_bindings(j);
        prefs_.server_url.clear();
        prefs_.builtin_torrents = jbool(j, "allow_torrents", false);
        const double cache=jnum(j,"torrent_cache_gb",6);
        prefs_.torrent_cache_gb=(cache==1||cache==2||cache==4||cache==6)?int(cache):6;
        prefs_.onboarding_done = jbool(j, "onboarding_done");
        prefs_.subtitle_langs = jstr(j, "subtitle_languages", prefs_.subtitle_langs);
        prefs_.auto_subtitles = jbool(j, "auto_subtitles", prefs_.auto_subtitles);
        prefs_.sub_size = jstr(j, "subtitle_size", prefs_.sub_size);
        prefs_.audio_langs = jstr(j, "audio_languages");
        prefs_.autoplay_next = jbool(j, "autoplay_next", prefs_.autoplay_next);
        prefs_.skip_segments = jbool(j, "skip_segments", true);
        prefs_.calm_backgrounds = jbool(j, "calm_backgrounds", prefs_.calm_backgrounds);
        prefs_.ui_sounds = jbool(j, "ui_sounds", prefs_.ui_sounds);
        prefs_.display_output = display_output_preference_name(display_output_preference(jstr(j, "display_output")));
        prefs_.display_refresh = jnum(j, "display_refresh", 60) == 120 ? 120 : 60;
        prefs_.native_hdr = jbool(j, "native_hdr", true);
        prefs_.auto_hdr_fallback = jbool(j,"auto_hdr_fallback",!j.contains("native_hdr"));
        prefs_.evo_player = jstr(j, "playback_engine") == "evo";
        prefs_.vlc_player = jstr(j, "playback_engine") == "vlc";
        const auto read_ahead = jnum(j, "read_ahead_seconds", 60);
        prefs_.read_ahead_seconds = (read_ahead == 30 || read_ahead == 60 || read_ahead == 120 || read_ahead == 300)
                                       ? static_cast<int>(read_ahead) : 60;
        prefs_.user_email = jstr(j, "user_email");
    }
}

void Session::save_prefs()
{
    json j;
    save_experience(j, prefs_);
    source_policy::save(j,prefs_.source_preferences);
    save_remote_bindings(j,prefs_.remote_bindings);
    j["onboarding_done"] = prefs_.onboarding_done;
    j["allow_torrents"] = prefs_.builtin_torrents;
    j["torrent_cache_gb"] = prefs_.torrent_cache_gb;
    j["subtitle_languages"] = prefs_.subtitle_langs;
    j["auto_subtitles"] = prefs_.auto_subtitles;
    j["subtitle_size"] = prefs_.sub_size;
    j["audio_languages"] = prefs_.audio_langs;
    j["autoplay_next"] = prefs_.autoplay_next;
    j["skip_segments"] = prefs_.skip_segments;
    j["calm_backgrounds"] = prefs_.calm_backgrounds;
    j["ui_sounds"] = prefs_.ui_sounds;
    j["display_output"] = prefs_.display_output;
    j["display_refresh"] = prefs_.display_refresh;
    j["native_hdr"] = prefs_.native_hdr;
    j["auto_hdr_fallback"] = prefs_.auto_hdr_fallback;
    j["playback_engine"] = prefs_.vlc_player ? "vlc" : prefs_.evo_player ? "evo" : "native";
    j["read_ahead_seconds"] = prefs_.read_ahead_seconds;
    save_profile_settings();
    j["user_email"] = prefs_.user_email;
    if (!save_json(data_dir_ + "/settings.json", j))
        say(sx::i18n::tr("Could not save settings to ") + data_dir_, 5.0, true);
}

void Session::load_progress()
{
    json j;
    const auto selected_source = jstr(tracking::Store(profile_dir_).status(), "progressPreferred", "nuvio");
    progress_file_ = tracking::provider(selected_source) ? "progress-"+selected_source+".json" : "progress.json";
    if (!load_json(profile_dir_ + "/"+progress_file_, j))
        return;
    const json &items = jobj(j, "items");
    if (items.is_object())
        for (auto it = items.begin(); it != items.end(); ++it)
        {
            Progress p;
            p.type = jstr(it.value(), "type");
            p.name = jstr(it.value(), "name");
            p.poster = jstr(it.value(), "poster");
            p.video_id = jstr(it.value(), "video_id");
            p.time = jnum(it.value(), "time");
            p.duration = jnum(it.value(), "duration");
            p.updated = static_cast<std::int64_t>(jnum(it.value(), "updated"));
            p.stream_json = jstr(it.value(), "stream");
            p.stream_video_id = jstr(it.value(), "stream_video");
            p.up_next = jstr(it.value(), "up_next");
            progress_[it.key()] = p;
        }
    const json &w = jobj(j, "watched");
    if (w.is_array())
        for (const auto &v : w)
            if (v.is_string())
                watched_.insert(v.get<std::string>());
    if(selected_source=="mdblist"&&(j.contains("watchedScopes")||j.contains("watchedExclusions"))) {
        // Retire the faulty read-side cache only. Preserve explicit marks,
        // resume data and the independent tracker write queue, even offline.
        j.erase("watchedScopes");j.erase("watchedExclusions");
        if(profile_ready_)save_json(profile_dir_+"/"+progress_file_,j);
    }
}

void Session::save_progress()
{
    json j;
    json items = json::object();
    for (const auto &kv : progress_)
        items[kv.first] = json{{"type", kv.second.type},         {"name", kv.second.name},
                               {"poster", kv.second.poster},     {"video_id", kv.second.video_id},
                               {"time", kv.second.time},         {"duration", kv.second.duration},
                               {"updated", kv.second.updated},   {"stream", kv.second.stream_json},
                               {"stream_video", kv.second.stream_video_id}, {"up_next", kv.second.up_next}};
    j["items"] = items;
    j["watched"] = json(std::vector<std::string>(watched_.begin(), watched_.end()));
    if (profile_ready_) save_json(profile_dir_ + "/"+progress_file_, j);
}

// ---------------------------------------------------------------------------
// Addons and the library

const ::Addon *Session::find_addon(const std::string &url) const
{
    for (const auto &a : addons_)
        if (a->transport_url == url)
            return a.get();
    return nullptr;
}

void Session::load_addons()
{
    stream_result_cache_.clear();
    struct Result
    {
        std::vector<std::shared_ptr<::Addon>> addons;
        std::vector<std::string> errors;
        bool auth_failed = false;
        bool account_failed = false;
    };
    if (!profile_ready_) return;
    const std::string key = prefs_.auth_key;
    const std::vector<std::string> extra = prefs_.extra_addons;
    const int gen = ++addons_gen_;
    addons_loading_ = true;
    bg<Result>(
        [key, extra]() {
            Result r;
            const auto manifest_deadline = std::chrono::steady_clock::now() + std::chrono::seconds(8);
            std::set<std::string> seen;
            if (!key.empty())
            {
                const ApiResult ar = api_addon_collection(key);
                if (ar.ok)
                {
                    if (jbool(ar.result, "offline"))
                        r.errors.push_back(sx::i18n::tr("Nuvio sync is unavailable. Using saved addons."));
                    if (!jstr(ar.result, "syncError").empty()) r.errors.push_back(jstr(ar.result, "syncError"));
                    const json &list = jobj(ar.result, "addons");
                    if (list.is_array())
                        for (const auto &e : list)
                        {
                            auto a = std::make_shared<::Addon>();
                            const std::string url = jstr(e, "transportUrl");
                            if (parse_addon(jobj(e, "manifest"), url, *a))
                            {
                                ::Addon fresh;
                                std::string refresh_error;
                                const auto remaining = std::chrono::duration_cast<std::chrono::seconds>(
                                    manifest_deadline - std::chrono::steady_clock::now()).count();
                                if (remaining > 0 && fetch_addon(url, fresh, refresh_error, nullptr,
                                                               std::min<long>(3, remaining)))
                                    *a = std::move(fresh);
                                a->from_account = true;
                                if (seen.insert(url).second)
                                    r.addons.push_back(a);
                            }
                        }
                }
                else
                {
                    r.account_failed = true;
                    r.errors.push_back(sx::i18n::tr("Could not load your addons (") + ar.error + ")");
                    const std::string l = lower(ar.error);
                    if (l.find("session") != std::string::npos || l.find("auth") != std::string::npos)
                        r.auth_failed = true;
                }
            }
            std::vector<std::string> urls;
            if (r.addons.empty())
                urls = {kCinemetaUrl, kOpenSubtitlesUrl};
            for (const auto &u : extra)
                urls.push_back(u);
            for (const auto &u : urls)
            {
                if (seen.count(u))
                    continue;
                auto a = std::make_shared<::Addon>();
                std::string err;
                if (fetch_addon(u, *a, err))
                {
                    seen.insert(u);
                    r.addons.push_back(a);
                }
                else
                {
                    r.errors.push_back(sx::i18n::tr("Could not reach an addon (") + err + ")");
                }
            }
            return r;
        },
        [this, gen](Result &r) {
            if (gen != addons_gen_)
                return;
            addons_loading_ = false;
            // Keep the working account addons across a transient sync failure.
            if (r.account_failed && !addons_.empty() && signed_in())
            {
                say(r.errors.front(), 6.0, true);
                return;
            }
            addons_.clear();
            const auto extra_before = prefs_.extra_addons;
            for (const auto &a : r.addons)
            {
                // Once a local addition is represented in the cloud snapshot,
                // stop treating it as a permanent local override of cloud deletes.
                if (a->from_account) {
                    auto& extra = prefs_.extra_addons;
                    extra.erase(std::remove(extra.begin(), extra.end(), a->transport_url), extra.end());
                }
                auto installed = std::make_unique<::Addon>(*a);
                for (auto &p : installed->providers)
                {
                    p.enabled = jbool(jobj(prefs_.provider_enabled, a->transport_url.c_str()), p.id.c_str());
                    const auto& settings=jobj(jobj(prefs_.provider_settings,a->transport_url.c_str()),p.id.c_str());
                    if(settings.is_object()) p.settings=settings;
                }
                addons_.push_back(std::move(installed));
            }
            if (extra_before != prefs_.extra_addons) save_prefs();
            if (signed_in()) for (const auto& a : addons_)
                if (!a->from_account &&
                    std::find(prefs_.extra_addons.begin(), prefs_.extra_addons.end(), a->transport_url) != prefs_.extra_addons.end() &&
                    !(a->provider_repository ? inherit_plugins_ : inherit_addons_))
                    sync_source(a->transport_url, a->provider_repository, false, true);
            if (!r.errors.empty())
                say(r.errors.front(), 6.0, true);
            if (r.auth_failed)
                say(sx::i18n::tr("Your Nuvio session expired. Sign in again in Settings."), 8.0, true);
            dlog("addons: %zu loaded", addons_.size());
            for (const auto &a : addons_)
                dlog("addons: %s, %zu catalogs", a->name.c_str(), a->catalogs.size());
            on_addons_loaded();
        });
}

void Session::on_addons_loaded()
{
    if(search_keyboard_open)search_keyboard_changed();
    build_board();
    // Discover starts again from the new catalogs the next time it opens.
    disc_items_.clear();
    discover.items.clear();
    disc_types_.clear();
    discover.status.clear();
    changed_ |= kDiscover | kDiscoverNew;
    refresh_addons();
    refresh_settings();
    if (page_ == Page::discover)
        enter_discover();
}

void Session::load_library()
{
    const std::string key = prefs_.auth_key;
    if (!profile_ready_ || key.empty() || library_loading_)
        return;
    library_loading_ = true;
    library_refresh_at_ = now_seconds() + 60;
    const int account_gen = login_gen_, library_gen = ++library_generation_;
    load_watched();
    bg<ApiResult>([key]() { return api_library_get(key); },
                  [this, key, account_gen, library_gen](ApiResult &r) {
                      if (library_gen != library_generation_) return;
                      library_loading_ = false;
                      if (prefs_.auth_key != key || login_gen_ != account_gen || !signed_in()) return;
                      if (!r.ok)
                      {
                          say(sx::i18n::tr("Could not load your library: ") + r.error, 5.0, true);
                          return;
                      }
                      if (!r.error.empty()) say(r.error, 12.0);
                      tracking_refresh();
                      const auto active = library_.find(w_item_.id);
                      json playing_item = watching && active != library_.end() ? active->second : json();
                      library_.clear();
                      if (r.result.is_array())
                          for (const auto &it : r.result)
                          {
                              const std::string id = jstr(it, "_id");
                              if (!id.empty())
                                  library_[id] = it;
                          }
                      if (playing_item.is_object()) library_[w_item_.id] = playing_item;
                      for (auto& [id,p] : progress_) {
                          if (watching && id == w_item_.id) continue;
                          if (!library_.count(id) || !jbool(jobj(library_[id],"state"),"nuvioSyncManaged")) { p.time = 0; p.up_next.clear(); }
                      }
                      for (const auto& [id, item] : library_)
                      {
                          if (watching && id == w_item_.id) continue;
                          const auto& state = jobj(item, "state");
                          if (!jbool(state, "nuvioSyncManaged")) continue;
                          Progress& p = progress_[id];
                          const auto video = jstr(state, "video_id");
                          if (video != p.video_id) p.up_next.clear();
                          if (jnum(state, "timeOffset") > 0) p.up_next.clear();
                          if (jnum(state, "timeOffset") <= 0 && !jbool(state, "nuvioCompleted")) p.up_next.clear();
                          p.type = jstr(item, "type"); p.name = jstr(item, "name"); p.poster = jstr(item, "poster");
                          p.video_id = video; p.time = jnum(state, "timeOffset") / 1000;
                          p.duration = jnum(state, "duration") / 1000;
                          p.updated = int64_t(jnum(state, "lastWatchedMs"));
                      }
                      save_progress();
                      library_loaded_ = true;
                      dlog("library: %zu items", library_.size());
                      refresh_board();
                      refresh_library();
                  });
}

void Session::addons_reload()
{
    providers::clear_script_cache();
    say(sx::i18n::tr("Reloading addons..."));
    load_addons();
    if (signed_in())
        load_library();
}

void Session::addon_activate(int index, int provider_cursor)
{
    if (index < 0 || index >= static_cast<int>(addons_.size()))
        return;
    const std::string url = addons_[static_cast<std::size_t>(index)]->transport_url;
    auto &selected = *addons_[static_cast<std::size_t>(index)];
    if (selected.provider_repository ? inherit_plugins_ : inherit_addons_) {
        say(sx::i18n::tr("This profile uses the primary profile's sources. Manage them in that profile."), 7.0); return;
    }
    if (selected.provider_repository)
    {
        std::vector<std::string> choices;
        for (const auto &p : selected.providers)
            choices.push_back(std::string(p.enabled ? "On: " : sx::i18n::tr("Off: ")) + p.name);
        const int count = static_cast<int>(choices.size());
        choices.push_back(sx::i18n::tr("Provider settings"));
        choices.push_back(sx::i18n::tr("Remove repository"));
        choices.push_back(sx::i18n::tr("Cancel"));
        open_dropdown(selected.name, choices, -1,
                      [this, url, count](int pick)
                      {
                          ::Addon *a = nullptr;
                          for (auto &candidate : addons_)
                              if (candidate->transport_url == url)
                                  a = candidate.get();
                          if (!a || pick < 0 || pick > count+1)
                              return;
                          if (pick == count)
                          {
                              provider_options(url); return;
                          }
                          if (pick == count+1)
                          {
                              auto &ex = prefs_.extra_addons;
                              ex.erase(std::remove(ex.begin(), ex.end(), url), ex.end());
                              prefs_.provider_enabled.erase(url);
                              prefs_.provider_settings.erase(url);
                              save_prefs();
                              sync_source(url, true, true);
                              load_addons();
                              return;
                          }
                          auto &p = a->providers[static_cast<size_t>(pick)];
                          p.enabled = !p.enabled;
                          prefs_.provider_enabled[url][p.id] = p.enabled;
                          save_prefs();
                          refresh_addons();
                          say(p.name + (p.enabled ? " enabled" : " disabled"));
                          // Keep the list open at the toggled provider so configuring a
                          // long repository doesn't restart navigation at the first row.
                          for (int i = 0; i < static_cast<int>(addons_.size()); ++i)
                              if (addons_[i]->transport_url == url) {
                                  addon_activate(i, pick);
                                  break;
                              }
                      });
        dropdown.selected = std::clamp(provider_cursor, 0, count + 2);
        dropdown.danger = count+1;
        return;
    }
    const auto it = std::find(prefs_.extra_addons.begin(), prefs_.extra_addons.end(), url);
    if (it == prefs_.extra_addons.end() && !selected.from_account)
    {
        say(sx::i18n::tr("Install and remove addons in the Nuvio app on your phone or computer; they sync here. Press Square to reload them now."),
            7.0);
        return;
    }
    open_dropdown(addons_[static_cast<std::size_t>(index)]->name, {sx::i18n::tr("Remove addon"), sx::i18n::tr("Keep")}, 1, [this, url](int i) {
        if (i != 0)
            return;
        auto &ex = prefs_.extra_addons;
        ex.erase(std::remove(ex.begin(), ex.end(), url), ex.end());
        save_prefs();
        sync_source(url, false, true);
        load_addons();
    });
}

// ---------------------------------------------------------------------------
// Addons and settings screens

void Session::refresh_addons()
{
    addons.items.clear();
    addon_logos_.clear();
    for (const auto &a : addons_)
    {
        sx::Addon row;
        row.name = a->name;
        row.version = a->version.empty() ? "" : "v" + a->version;
        row.description = a->description;
        if (a->provider_repository)
        {
            size_t enabled = 0;
            for (const auto &p : a->providers)
                enabled += p.enabled;
            row.description = sx::i18n::tr("Plugin repository · ") + std::to_string(enabled) + " of " +
                              std::to_string(a->providers.size()) + sx::i18n::tr(" providers enabled. Select to manage.");
        }
        std::vector<std::string> types;
        for (const auto &t : a->types)
            types.push_back(t);
        row.types = join(types, " ");
        row.local = !a->from_account;
        row.initial = first_letter(a->name);
        row.colour = colour_for(a->name);
        addons.items.push_back(row);
        addon_logos_.push_back(jstr(a->manifest, "logo"));
    }
    changed_ |= kAddons;
    art_dirty_ = true;
}

void Session::set_display_configuration(unsigned width, unsigned height, bool fallback)
{
    configured_w_ = width; configured_h_ = height;
    dlog("display: PS5 configured %ux%u at startup; render %dx%d SDR 8-bit; accepted refresh %d Hz; fallback %d",
         width, height, output_w_, output_h_, output_hz_, fallback);
    if (fallback)
        say(sx::i18n::tr("Display fallback active. Check Display output in Settings; reopen Nuvio Max'd after changing it."), 12.0, true);
}

void Session::refresh_settings()
{
    settings.subtitle_style = prefs_.subtitle_style;
    settings.subtitle_size = subtitle_size::index(prefs_.sub_size);
    settings.account = prefs_.user_email;
    settings.rows.assign(kSettingCount, SettingRow());
    const auto set = [&](int i, SettingRow::Kind kind, const char *label, const std::string &value, const std::string &help,
                         bool on = false) {
        SettingRow &r = settings.rows[static_cast<std::size_t>(i)];
        r.kind = kind;
        r.label = label;
        r.value = value;
        r.help = help;
        r.on = on;
    };
    using Kind = SettingRow::Kind;
    set(kBuildIntegrity,Kind::action,i18n::tr("Build authenticity & credits"),integrity_status(integrity_result_.status),
        i18n::tr("Verify release files and required credits offline. This check does not block playback."));
    set(kAgeRatingCountry,Kind::value,i18n::tr("Age-rating country"),prefs_.age_rating_country,
        i18n::tr("Choose the country for title certifications. US ratings are used when unavailable. The badge shows its country. Saved for this profile; display only."));
    set(kUiLanguage,Kind::value,i18n::tr("Language"),i18n::native_name(prefs_.ui_language),i18n::tr("Use the app menus in your preferred language. Restart Max'd to apply.")+std::string(" ")+i18n::tr("Some help and status messages may appear in English."));
    set(kStartPage,Kind::value,i18n::tr("Open Max'd on"),i18n::tr(start_page::choices[start_page::index(prefs_.start_page)].label),i18n::tr("Choose the page to open after selecting this profile. Disabled Sports falls back to Home. Playback does not start automatically."));
    set(kTopNavigation,Kind::toggle,i18n::tr("Top navigation"),"",i18n::tr("Show a top menu with a Search tab. Use L1/R1 to switch tabs; Live TV and torrent controls keep their shortcuts. Saved for this profile."),top_navigation);
    set(kMediaServers, SettingRow::Kind::action, sx::i18n::tr("Media servers (experimental)"), std::to_string(media_accounts_.size())+" connected", sx::i18n::tr("Connect Jellyfin, Emby or Plex. Browse server libraries and resume playback separately from addons."));
    set(kAccount, Kind::value, sx::i18n::tr("Nuvio account"), signed_in() ? prefs_.user_email : sx::i18n::tr("Not signed in"),
        signed_in() ? (confirm_sign_out_ ? sx::i18n::tr("Press Cross again to sign out.") : sx::i18n::tr("Press Cross to sign out."))
                    : sx::i18n::tr("Sign in with a QR code to choose a profile and load its addons and saved library. Press Cross."));
    set(kProfiles, Kind::value, sx::i18n::tr("Profiles"), signed_in() ? jstr(active_profile_, "name", sx::i18n::tr("Choose profile")) : sx::i18n::tr("Sign in first"),
        sx::i18n::tr("Import or switch Nuvio account profiles, or create a profile. Each has separate history and sources."));
    set(kTorrents, Kind::toggle, sx::i18n::tr("Peer-to-peer torrents"), "",
        sx::i18n::tr("Off uses direct and debrid links from your configured addons. Turn on to also download raw torrents."),
        prefs_.builtin_torrents);
    set(kTorrentOptions,Kind::action,sx::i18n::tr("Torrent settings"),prefs_.builtin_torrents?sx::i18n::tr("Enabled"):sx::i18n::tr("Off"),
        sx::i18n::tr("Cache limit and storage usage, safe buffered-data cleanup, and paired Web Drop. .torrent files and watch progress are kept separately."));
    const int connections = int(!services_.torbox.key.empty()) + int(!services_.premiumize.key.empty()) + int(!services_.animeskip.key.empty());
    set(kConnectedServices, Kind::value, sx::i18n::tr("Connected Services"), connections ? std::to_string(connections) + " connected" : "TorBox / Premiumize",
        sx::i18n::tr("Connect TorBox or Premiumize, import connections from Nuvio Sync, and prepare cached links for faster playback. The selected file keeps its original quality."));
    set(kTracking, Kind::value, sx::i18n::tr("Tracking accounts"), "Trakt / SIMKL / MDBList",
        sx::i18n::tr("Connect trackers for this profile. Connecting does not change your Library Source or Watch Progress choice."));
    const auto library_source = jstr(tracking_status_, "library", "nuvio");
    const auto progress_source = jstr(tracking_status_, "progress", "nuvio");
    set(kLibrarySource, Kind::value, sx::i18n::tr("Library Source"), library_source == "nuvio" ? sx::i18n::tr("Nuvio Library") : tracking::name(library_source),
        sx::i18n::tr("Choose which source Nuvio reads for your Library. Connected trackers become available here. Nuvio Library is the default."));
    set(kServer, Kind::value, sx::i18n::tr("Watch Progress"), progress_source == "nuvio" ? sx::i18n::tr("Nuvio Sync") : tracking::name(progress_source),
        sx::i18n::tr("Choose which progress source powers resume and Continue Watching. Nuvio Sync is the default; guest progress stays on this PS5."));
    if (jstr(tracking_status_, "libraryPreferred", "nuvio") != library_source)
        settings.rows[kLibrarySource].help += sx::i18n::tr(" Tracker unavailable. Using Nuvio Library until it reconnects.");
    if (jstr(tracking_status_, "progressPreferred", "nuvio") != progress_source)
        settings.rows[kServer].help += sx::i18n::tr(" Tracker unavailable. Using Nuvio Sync until it reconnects.");
    const char* display_labels[] = {sx::i18n::tr("Follow PS5"), "1080p", "1440p", "4K"};
    set(kDisplay, Kind::value, sx::i18n::tr("Display output"), display_labels[display_output_preference(prefs_.display_output) + 1],
        sx::i18n::tr("Follow the PS5's output resolution, or choose an override. Close and reopen Nuvio Max'd to apply a change."));
    set(kHdr, Kind::value, i18n::tr("HDR playback"), prefs_.native_hdr ? (prefs_.auto_hdr_fallback ? sx::i18n::tr("Auto (HDR or SDR fallback)") : sx::i18n::tr("Require native HDR10")) : sx::i18n::tr("Convert HDR to SDR"),
        sx::i18n::tr("Native HDR10 keeps PQ colour and highlights on a compatible TV. SDR conversion changes the colour range. Applies to the next stream."));
    set(kPlaybackEngine, Kind::value, sx::i18n::tr("Playback engine"), prefs_.vlc_player ? i18n::tr("VLC 3.0.24 (experimental)") : prefs_.evo_player ? sx::i18n::tr("EVO Player 0.13.7 (experimental)") : sx::i18n::tr("Nuvio native"),
        sx::i18n::tr("Choose the video engine. Applies to the next stream; subtitles and Watch Progress stay available."));
    set(kReadAhead, Kind::value, sx::i18n::tr("Read-ahead (Native/EVO)"), std::to_string(prefs_.read_ahead_seconds) + " s",
        sx::i18n::tr("How far to buffer ahead. Memory limits may shorten the target. Applies to the next Native/EVO stream; VLC manages its own buffer."));
    set(kRefresh, Kind::value, sx::i18n::tr("Display refresh"), prefs_.display_refresh == 120 ? sx::i18n::tr("Prefer 120 Hz") : "60 Hz",
        sx::i18n::tr("120 Hz can make 24 fps films feel steadier on a compatible TV. Keeps the selected resolution; uses 60 Hz if unavailable. Close and reopen to apply."));
    const std::vector<std::string> night_modes{sx::i18n::tr("Off"), sx::i18n::tr("Light"), sx::i18n::tr("Medium"), sx::i18n::tr("Strong")};
    set(kNightMode, Kind::value, sx::i18n::tr("Night Mode"), night_modes[std::clamp(prefs_.night_mode,0,3)], sx::i18n::tr("Lift quiet dialogue with linked-channel compression and peak limiting. Off by default. Uses PCM; applies to the next video on all players."));
    set(kLfeMix, Kind::value, sx::i18n::tr("Bass in stereo downmix"), std::to_string(prefs_.lfe_mix_percent)+"%", sx::i18n::tr("Native/EVO: include the surround LFE channel in stereo, with normalized headroom. Default 50%; Off drops LFE. VLC uses its own downmix. Applies to the next video."));
    set(kSubtitleAutoSync, Kind::toggle, sx::i18n::tr("Subtitle auto-sync"), "", sx::i18n::tr("Native/EVO: align addon subtitles to embedded text timings already read from the file. Off by default. Requires enough matching cues; uncertain matches keep manual timing. No speech or video is uploaded."),prefs_.subtitle_auto_sync);
    set(kTrailerLanguage, Kind::value, sx::i18n::tr("Trailer language"), prefs_.trailer_language.empty()?sx::i18n::tr("Follow preferred languages"):i18n::tr(language_name(prefs_.trailer_language)), sx::i18n::tr("Prefer this language when finding trailers, with English as a fallback. Automatic follows audio then subtitle preferences."));
    set(kChapterSkip, Kind::toggle, sx::i18n::tr("Skip buttons from chapters"), "", sx::i18n::tr("Use explicitly named opening, recap and credits chapters when available. Regular chapters and post-credit scenes are preserved. Requires Skip intro / recap / credits."),prefs_.chapter_skip_segments);
    set(kAudioGain, Kind::value, sx::i18n::tr("Audio volume / boost"), std::to_string(prefs_.audio_gain_percent)+"%", sx::i18n::tr("50–300%; uses PCM. Boost can distort loud peaks. Default 100%."));
    set(kAudioDelay, Kind::value, sx::i18n::tr("Audio sync delay"), std::to_string(prefs_.audio_delay_ms)+" ms", sx::i18n::tr("Positive: sound later relative to picture. Negative: sound earlier. Default 0 ms."));
    set(kSubtitleDelay, Kind::value, sx::i18n::tr("Subtitle sync delay"), std::to_string(prefs_.subtitle_delay_ms)+" ms", sx::i18n::tr("Positive: subtitles later; negative: earlier. Also adjustable during playback."));
    set(kAudioMode, Kind::value, sx::i18n::tr("Audio output"), prefs_.vlc_player?"PCM (VLC)":prefs_.audio_output_mode=="pcm"?"PCM":prefs_.audio_output_mode=="auto"?sx::i18n::tr("Auto (experimental)"):sx::i18n::tr("Bitstream (experimental)"),
        prefs_.vlc_player ? sx::i18n::tr("VLC currently uses decoded PCM. Auto and Bitstream apply to Native/EVO playback.") : sx::i18n::tr("Auto uses PCM with Surround off; with Surround on it checks HDMI capabilities. Bitstream forces a compressed-format attempt. Applies to the next video."));
    set(kAudioOutput, Kind::toggle, sx::i18n::tr("Surround audio"), "", sx::i18n::tr("Use 7.1 PCM for compatible HDMI surround systems. Keep off for TV speakers or optical stereo. Applies to the next video."), prefs_.surround_audio);
    set(kSubLangs, Kind::value, sx::i18n::tr("Subtitle languages"), prefs_.subtitle_langs.empty() ? sx::i18n::tr("None") : prefs_.subtitle_langs,
        sx::i18n::tr("Preferred order, for example \"gre, eng\"."));
    set(kAutoSubs, Kind::toggle, sx::i18n::tr("Subtitles on automatically"), "", sx::i18n::tr("Prefer matching subtitles inside the video file. Use addon subtitles when the file has no matching track."),
        prefs_.auto_subtitles);
    set(kSubSize, Kind::value, sx::i18n::tr("Subtitle size"), size_label(prefs_.sub_size), sx::i18n::tr("How large subtitles are drawn over the video."));
    static const char* fonts[]={sx::i18n::tr("Regular"), sx::i18n::tr("Bold"), sx::i18n::tr("Display")};
    static const char* colours[]={sx::i18n::tr("White"), sx::i18n::tr("Yellow"), sx::i18n::tr("Cyan")};
    static const char* effects[]={sx::i18n::tr("Plain"), sx::i18n::tr("Outline"), sx::i18n::tr("Shadow")};
    set(kSubFont, Kind::value, sx::i18n::tr("Subtitle font"), fonts[prefs_.subtitle_style.font], sx::i18n::tr("Choose the subtitle face. Unicode fallbacks remain available."));
    set(kSubColour, Kind::value, sx::i18n::tr("Subtitle colour"), colours[prefs_.subtitle_style.colour], sx::i18n::tr("Choose a colour that is comfortable to read."));
    set(kSubEffect, Kind::value, sx::i18n::tr("Subtitle effect"), effects[prefs_.subtitle_style.effect], sx::i18n::tr("Add an outline or shadow to separate text from the picture."));
    set(kSubBackground, Kind::value, sx::i18n::tr("Subtitle background"), std::to_string(prefs_.subtitle_style.background)+"%", sx::i18n::tr("Choose the opacity behind subtitle text."));
    for(int i : {kSubSize,kSubFont,kSubColour,kSubEffect,kSubBackground}) settings.rows[i].subtitle_preview=true;
    set(kSeek, Kind::value, sx::i18n::tr("D-pad seek interval"), std::to_string(prefs_.seek_seconds)+" s", sx::i18n::tr("How far Left and Right skip during playback."));
    set(kShoulderSeek, Kind::value, sx::i18n::tr("L1 / R1 seek interval"), std::to_string(prefs_.shoulder_seek_seconds)+" s", sx::i18n::tr("How far the shoulder buttons skip during playback."));
    set(kCountdown, Kind::value, sx::i18n::tr("Next-episode countdown"), std::to_string(prefs_.next_episode_seconds)+" s", sx::i18n::tr("Countdown during credits or when an episode ends, once a matching stream is ready. Pause or buffering holds the countdown; Circle cancels it."));
    set(kReducedMotion, Kind::toggle, sx::i18n::tr("Reduced motion"), "", sx::i18n::tr("Make focus, scrolling and menu transitions immediate; keep decorative backgrounds still."), prefs_.reduced_motion);
    set(kHighContrast, Kind::toggle, sx::i18n::tr("Higher contrast"), "", sx::i18n::tr("Brighter interface text and stronger panel and focus boundaries. The video picture is unchanged."), prefs_.high_contrast);
    set(kReleaseNotes, Kind::action, sx::i18n::tr("What’s new"), "Nuvio Max’d " + std::string(nuvio_update::current_version), sx::i18n::tr("Read the changes in this version again."));
    set(kDiagnostics, Kind::action, sx::i18n::tr("Playback diagnostics"), "", sx::i18n::tr("Show or save a privacy-safe summary; scan its QR code to copy text on your phone. Detailed private logs stay on this console."));
    set(kAudioLangs, Kind::value, sx::i18n::tr("Audio languages"), prefs_.audio_langs.empty() ? sx::i18n::tr("Default") : prefs_.audio_langs,
        sx::i18n::tr("Preferred audio track language, for example \"eng\". Leave empty for the default."));
    set(kAutoplay, Kind::toggle, sx::i18n::tr("Play next episode automatically"), "", sx::i18n::tr("Show a cancellable countdown during credits or at the end of an episode. Match the selected stream quality."),
        prefs_.autoplay_next);
    set(kSkipSegments, Kind::toggle, sx::i18n::tr("Skip intro and recap buttons"), "",
        sx::i18n::tr("Use IntroDB and anime timing services for intros, recaps and credits. Coverage varies by show and release."), prefs_.skip_segments);
    set(kCalmBackgrounds, Kind::toggle, sx::i18n::tr("Calmer backgrounds"), "", sx::i18n::tr("Keep decorative menu backgrounds still. Video playback stays full quality."), prefs_.calm_backgrounds);
    set(kUiSounds, Kind::toggle, sx::i18n::tr("Interface sounds"), "", sx::i18n::tr("A soft sound when you move around, go back or switch page."), prefs_.ui_sounds);
    set(kAddAddon, Kind::value, sx::i18n::tr("Add addon or plugin URL"), "",
        prefs_.extra_addons.empty()
            ? sx::i18n::tr("A Stremio addon or Nuvio provider manifest URL. Manage providers on the Addons page.")
            : std::to_string(prefs_.extra_addons.size()) + sx::i18n::tr(" added here."));
    set(kReload, Kind::action, sx::i18n::tr("Reload addons and catalogs"), "", sx::i18n::tr("Fetch every addon and catalog again."));
    const auto update = updater_.status();
    set(kMetadataCredits, Kind::action, sx::i18n::tr("Metadata credits"), "TMDB / TheTVDB", sx::i18n::tr("This product uses the TMDB API but is not endorsed or certified by TMDB."));
    set(kDonation, Kind::action, sx::i18n::tr("Support on Ko-fi"), "", sx::i18n::tr("Optional support for development. Scan the QR code with your phone."));
    set(kInstallSource, Kind::value, sx::i18n::tr("Install source"), install_source_label(prefs_.install_source),
        sx::i18n::tr("Where you installed Nuvio Max'd. Update reminders use this choice; change it if you switch install methods."));
    set(kUpdates, Kind::value, sx::i18n::tr("App updates"), update.phase == AppUpdate::Phase::idle ? "Nuvio Max'd " + std::string(nuvio_update::current_version) : update.message,
        update_destination(prefs_.install_source));
    set(kExit, Kind::action, sx::i18n::tr("Exit Nuvio Max'd"), "", sx::i18n::tr("Close the app and go back to the home screen."));
    set(kRemoteButtons,Kind::action,sx::i18n::tr("Remote buttons (experimental)"),std::to_string(prefs_.remote_bindings.size())+" mapped",sx::i18n::tr("Assign buttons received from your Media Remote or TV remote to Search, Options, navigation, playback or seeking. PS5/TV system buttons may not reach this app. Controller controls are unchanged."));
    set(kConsoleLights, Kind::toggle, sx::i18n::tr("Console light sync"), "", sx::i18n::tr("Fade the console lights with the controller while Nuvio is open. Console colours are approximate. Unsupported systems leave their lights unchanged. Turning off restores the previous state."), prefs_.console_light_sync);
    const char* light_status = console_light_status_==ConsoleLights::Status::active ? sx::i18n::tr("Sync active.") :
        console_light_status_==ConsoleLights::Status::unavailable ? sx::i18n::tr("Console light access is unavailable on this system.") :
        console_light_status_==ConsoleLights::Status::system_owned ? sx::i18n::tr("System lighting took priority; toggle off and on to retry.") : sx::i18n::tr("Waiting for Nuvio to be in front.");
    if(prefs_.console_light_sync) settings.rows[kConsoleLights].help += std::string(" ")+light_status;
    const auto group = [&](const char* name,std::initializer_list<int> ids) {
        for(int id:ids) settings.rows[id].category=name;
    };
    group("Account & Services", {kAccount,kProfiles,kTracking,kLibrarySource,kConnectedServices,kServer,kMediaServers,kAgeRatingCountry});
    group("Video", {kDisplay,kRefresh,kHdr,kPlaybackEngine});
    group("Audio", {kAudioMode,kAudioOutput,kAudioLangs,kAudioGain,kAudioDelay,kNightMode,kLfeMix});
    group("Subtitles", {kSubLangs,kAutoSubs,kSubSize,kSubFont,kSubColour,kSubEffect,kSubBackground,kSubtitleDelay,kSubtitleAutoSync});
    group("Playback", {kSeek, kShoulderSeek, kCountdown, kAutoplay, kSkipSegments, kReadAhead, kChapterSkip, kTrailerLanguage});
    group("Appearance & Lighting", {kReducedMotion,kHighContrast,kUiSounds,kCalmBackgrounds,kConsoleLights});
    set(kSourceOptions,Kind::action,sx::i18n::tr("Source preferences"),sx::i18n::tr("Quality, language and checks"),sx::i18n::tr("Rank sources using advertised metadata. Filter likely samples, wrong episodes, quality, size and HDR. Unknown metadata remains available. Preferences belong to this profile."));
    group("Addons", {kAddAddon,kReload,kSourceOptions});
    set(kFreeTv,Kind::toggle,i18n::tr("Free live TV"),"",i18n::tr("Watch free public channels without an IPTV subscription. Optional for this profile."),free_tv::enabled(live_state_));
    auto free_country=free_tv::country(live_state_);for(auto& c:free_country)c=char(std::toupper(static_cast<unsigned char>(c)));
    for(const auto& row:free_tv_countries_)if(row.code==free_tv::country(live_state_)){free_country=row.name;break;}
    const auto free_count=free_tv::selected_countries(live_state_).size();
    if(free_count>1)free_country=replace_all(i18n::tr("{count} countries selected"),"{count}",std::to_string(free_count));
    set(kFreeTvCountry,Kind::value,i18n::tr("Free TV countries"),free_country,i18n::tr("Choose one or more countries for the free channel list."));
    set(kFreeTvOpen,Kind::action,i18n::tr("Open free live TV"),"",i18n::tr(free_tv::enabled(live_state_)?"Watch free public channels without an IPTV subscription. Optional for this profile.":"Read the disclaimer and enable Free live TV first."));
    set(kUnifiedTv,Kind::action,i18n::tr("Unified TV guide"),"",i18n::tr("Browse your IPTV sources and enabled free channels together. Source names identify each channel."));
    set(kLiveRefresh,Kind::value,i18n::tr("Channel list auto-refresh"),i18n::tr(live_refresh::choices[live_refresh::index(live_refresh::hours(live_state_))].label),
        i18n::tr("Refresh loaded free and personal channel lists while Max'd is open. Waits during playback and menus. Failed downloads keep the last working list. Guide updates are separate.")+
        (live_refresh_failed_?std::string(" ")+i18n::tr("The last refresh failed; the previous channel list was kept."):""));
    group("Live TV",{kUnifiedTv,kFreeTv,kFreeTvCountry,kFreeTvOpen,kLiveRefresh});
    set(kSportsEnable,Kind::toggle,sx::i18n::tr("Sports Hub"),"",sx::i18n::tr("Show Sports Hub in navigation for this profile. Off stops sports requests and keeps your selections."),sports_prefs_.enabled);
    const auto sports_state=sports_prefs_.enabled?"":sx::i18n::tr("Enable Sports Hub first");
    set(kSportsOpen,Kind::action,sx::i18n::tr("Open Sports Hub"),sports_state,sx::i18n::tr("Browse schedules, results and matching channels from your own Live TV sources."));
    set(kSportsRegion,Kind::action,sx::i18n::tr("Sports coverage region"),sports_prefs_.enabled?sports_prefs_.region:sports_state,sx::i18n::tr("Choose broadcaster coverage preferences; competitions remain selectable in every region."));
    set(kSportsBrowse,Kind::action,sx::i18n::tr("Choose sports and competitions"),sports_state,sx::i18n::tr("Sport → league → teams. Include or exclude whole sports and individual competitions."));
    set(kSportsFollowing,Kind::action,sx::i18n::tr("Follow teams, leagues and names"),sports_state,sx::i18n::tr("Manage My Sports. Follow teams across supported competitions or add an athlete/name to find in your guide."));
    set(kSportsScores,Kind::toggle,sx::i18n::tr("Hide sports scores"),"",sx::i18n::tr("Hide scores and live score details to avoid spoilers."),sports_prefs_.hide_scores);
    set(kSportsChannels,Kind::toggle,sx::i18n::tr("Only events with channel matches"),"",sx::i18n::tr("Limit the hub to events with guide or broadcaster candidates in your loaded Live TV source. A broadcaster alone does not confirm the programme."),sports_prefs_.only_channels);
    set(kSportsClock,Kind::action,sx::i18n::tr("Sports time display"),sports_prefs_.enabled?std::string("UTC ")+(sports_prefs_.utc_offset>=0?"+":"")+std::to_string(sports_prefs_.utc_offset)+" min":sports_state,sx::i18n::tr("Fixed UTC offset in 15-minute steps. Adjust when daylight-saving time changes."));
    group("Sports Hub",{kSportsEnable,kSportsOpen,kSportsRegion,kSportsBrowse,kSportsFollowing,kSportsScores,kSportsChannels,kSportsClock});
    group("Torrents",{kTorrents,kTorrentOptions});
    group("Controls",{kRemoteButtons});
    set(kTvdb,Kind::action,i18n::tr("TheTVDB episode ordering"),"",i18n::tr("Use your TVDB API key, then choose an episode order from a series title menu."));
    set(kConfigBackup,Kind::action,i18n::tr("Configuration backup and sync"),"",i18n::tr("Encrypted profile configuration backups. Account sessions and playback history are excluded."));
    group("App & Updates", {kStartPage,kTopNavigation,kTvdb,kConfigBackup,kUiLanguage,kBuildIntegrity,kReleaseNotes,kDiagnostics,kMetadataCredits,kDonation,kInstallSource,kUpdates,kExit});
    changed_ |= kSettings;
}

void Session::settings_activate(int row)
{
    if(backup_busy_){say(i18n::tr("Backup operation in progress..."));return;}
    if(row==kUnifiedTv){live_unified_open();return;}
    if(row==kFreeTv){free_tv_toggle();return;}
    if(row==kFreeTvCountry){free_tv_country_menu();return;}
    if(row==kFreeTvOpen){free_tv_open();return;}
    if(row==kLiveRefresh){live_refresh_menu();return;}
    if(row==kTvdb){tvdb_menu();return;}
    if(row==kConfigBackup){backup_menu();return;}
    if(row==kBuildIntegrity){integrity_menu();return;}
    if(row==kStartPage){start_page_menu();return;}
    if(row==kTopNavigation){
        if(!profile_ready_){say(i18n::tr("Choose a profile first."),6);return;}
        const bool previous=top_navigation;top_navigation=!top_navigation;save_profile_settings();json stored;
        if(!load_json(profile_dir_+"/profile-settings.json",stored)||jbool(stored,"top_navigation",previous)!=top_navigation){top_navigation=previous;say(i18n::tr("Could not save profile preferences"),6,true);}
        refresh_settings();return;
    }
    if(row==kAgeRatingCountry){age_rating_country_menu();return;}
    if(row==kUiLanguage){
        std::vector<std::string> names,codes;for(const auto& locale:i18n::locales()){names.emplace_back(locale.native_name);codes.emplace_back(locale.code);}
        open_dropdown(i18n::tr("Language"),names,int(i18n::index(prefs_.ui_language)),[this,codes](int n){
            if(n<0||n>=int(codes.size()))return;const auto previous=prefs_.ui_language;prefs_.ui_language=codes[size_t(n)];save_prefs();
            json stored;const bool saved=load_json(data_dir_+"/settings.json",stored)&&jstr(stored,"ui_language")==prefs_.ui_language;
            if(!saved)prefs_.ui_language=previous;refresh_settings();
            say(saved?sx::i18n::tr("Language saved. Restart Max'd to apply."):sx::i18n::tr("Could not save language. Try again."),8,!saved);
        });dropdown.message=i18n::tr("Some help and status messages may appear in English.");return;
    }
    if(row==SettingsNavigation::search_action) {
        const auto profile=profile_generation_;
        ask_search([this,profile](const std::string& query) {
            if(profile!=profile_generation_ || trim(query).empty())return;
            const auto matches=SettingsNavigation::search(settings,query);
            if(matches.empty()){say(sx::i18n::tr("No matching settings. Try a shorter name or another word."),7.0);return;}
            std::vector<std::string> choices;
            for(int id:matches)choices.push_back(settings.rows[id].label+" — "+SettingsNavigation::group(settings.rows[id]));
            open_dropdown(sx::i18n::tr("Matching settings"),choices,0,[this,profile,matches](int pick) {
                if(profile!=profile_generation_ || pick<0 || pick>=int(matches.size()))return;
                settings_activate(matches[pick]);
            });
        },sx::i18n::tr("Search settings"));
        return;
    }
    if (signed_in() && !profile_ready_ &&
        (row == kSourceOptions || row == kMediaServers || row == kTracking || row == kLibrarySource || row == kConnectedServices || row == kServer || row == kAddAddon || row == kReload ||
         row == kSubLangs || row == kAudioLangs || row == kAutoSubs)) {
        say(sx::i18n::tr("Choose a profile in Account & Services > Profiles first."), 7.0); return;
    }

    if (row != kAccount && confirm_sign_out_)
        confirm_sign_out_ = false;
    if(row>=kSportsEnable&&row<=kSportsClock) {
        if(!profile_ready_){say(sx::i18n::tr("Choose a profile first."),6);return;}
        if(row==kSportsEnable){sports_toggle();return;}
        if(!sports_prefs_.enabled){say(sx::i18n::tr("Enable Sports Hub in this section first."),6);return;}
        if(row==kSportsOpen){goto_=Page::sports;return;}
        if(row==kSportsRegion)sports_region();else if(row==kSportsBrowse)sports_browse();
        else if(row==kSportsFollowing)sports_following();else if(row==kSportsScores)sports_scores();
        else if(row==kSportsChannels)sports_channel_filter();else if(row==kSportsClock)sports_clock();return;
    }
    switch (row)
    {
    case kConsoleLights:
        prefs_.console_light_sync=!prefs_.console_light_sync; save_prefs(); cue(hui::audio::Cue::toggle); break;
    case kMediaServers: media_menu(); break;
    case kConnectedServices:
        services_menu();
        break;
    case kProfiles: profiles_menu(); break;
    case kTracking: tracking_menu(); break;
    case kLibrarySource: tracking_source_menu(false); break;
    case kAccount:
        if (!signed_in())
            login_start();
        else if (!confirm_sign_out_)
            confirm_sign_out_ = true;
        else
        {
            confirm_sign_out_ = false;
            sign_out();
        }
        break;
    case kRemoteButtons:remote_menu();break;
    case kSourceOptions: source_options();break;
    case kTorrentOptions: torrent_menu(true);break;
    case kTorrents:
        prefs_.builtin_torrents = !prefs_.builtin_torrents;
        if(!prefs_.builtin_torrents){
            if(watching && t_visible_ && starts_with(t_stats_url_,"torrent://"))watch_stop(false);
            torrent_reset();
        }
        bt::Engine::get().set_enabled(prefs_.builtin_torrents);
        torrents_visible=prefs_.builtin_torrents;
        if(torrents_visible)torrent_load();
        changed_|=kTorrentPage;
        save_prefs();
        cue(hui::audio::Cue::toggle);
        detail_refresh_streams();
        break;
    case kServer:
        tracking_source_menu(true);
        break;
    case kDisplay:
        open_dropdown(sx::i18n::tr("Display output"), {sx::i18n::tr("Follow PS5"), "1080p", "1440p", "4K"},
                      display_output_preference(prefs_.display_output) + 1, [this](int i) {
            if (i < 0 || i > 3) return;
            prefs_.display_output = display_output_preference_name(i - 1);
            save_prefs();
            cue(hui::audio::Cue::saved);
            say(sx::i18n::tr("Display choice saved. Close and reopen Nuvio Max'd to apply it."), 8.0);
            refresh_settings();
        });
        break;
    case kRefresh:
        open_dropdown(sx::i18n::tr("Display refresh"), {"60 Hz", sx::i18n::tr("Prefer 120 Hz")},
                      prefs_.display_refresh == 120 ? 1 : 0, [this](int i) {
            if (i != 0 && i != 1) return;
            prefs_.display_refresh = i == 1 ? 120 : 60;
            save_prefs(); refresh_settings(); cue(hui::audio::Cue::saved);
            say(sx::i18n::tr("Refresh choice saved. Close and reopen Nuvio Max'd to apply it."),8.0);
        });
        break;
    case kSubLangs:
        ask_text([this](const std::string &v) {
            if (trim(v).empty())
                return;
            prefs_.subtitle_langs = trim(v);
            save_prefs();
            cue(hui::audio::Cue::saved);
            refresh_settings();
        });
        break;
    case kHdr:
        open_dropdown("HDR playback", {sx::i18n::tr("Auto (HDR or SDR fallback)"), sx::i18n::tr("Require native HDR10"), sx::i18n::tr("Convert HDR to SDR")},
                      !prefs_.native_hdr ? 2 : prefs_.auto_hdr_fallback ? 0 : 1, [this](int i) {
            if (i < 0 || i > 2) return;
            prefs_.native_hdr = i != 2;
            prefs_.auto_hdr_fallback = i == 0;
            save_prefs(); refresh_settings(); cue(hui::audio::Cue::saved);
        });
        break;
    case kPlaybackEngine: {
        std::vector<std::string> engines={sx::i18n::tr("Nuvio native"), sx::i18n::tr("EVO Player 0.13.7 (experimental)")};
        if(VlcBackend::available())engines.push_back("VLC 3.0.24 (experimental)");
        open_dropdown(sx::i18n::tr("Playback engine"), engines,
                      prefs_.vlc_player && VlcBackend::available() ? 2 : prefs_.evo_player ? 1 : 0, [this](int i) {
            if(i<0 || i>2 || (i==2 && !VlcBackend::available()))return;
            prefs_.evo_player=i==1;prefs_.vlc_player=i==2;
            save_prefs(); refresh_settings(); cue(hui::audio::Cue::saved);
        });
        break;
    }
    case kReadAhead:
    {
        const std::vector<int> values = {30, 60, 120, 300};
        const int selected =
            static_cast<int>(std::find(values.begin(), values.end(), prefs_.read_ahead_seconds) - values.begin());
        open_dropdown(sx::i18n::tr("Read-ahead"), {"30 seconds", "1 minute", "2 minutes", "5 minutes"}, selected,
                      [this, values](int i)
                      {
                          if (i < 0 || i >= static_cast<int>(values.size()))
                              return;
                          prefs_.read_ahead_seconds = values[i];
                          save_prefs();
                          refresh_settings();
                          cue(hui::audio::Cue::saved);
                      });
        break;
    }
    case kSubFont: {
        static constexpr int values[] = {0,1,2};
        int selected=0; for(int i=0;i<3;++i) if(prefs_.subtitle_style.font==values[i]) selected=i;
        open_dropdown(sx::i18n::tr("Subtitle font"), {sx::i18n::tr("Regular"),sx::i18n::tr("Bold"),sx::i18n::tr("Display")}, selected, [this](int i) {
            if(i<0 || i>=3) return;
            prefs_.subtitle_style.font=values[i]; save_prefs(); refresh_settings(); cue(hui::audio::Cue::saved);
        }); break;
    }
    case kSubColour: {
        static constexpr int values[] = {0,1,2};
        int selected=0; for(int i=0;i<3;++i) if(prefs_.subtitle_style.colour==values[i]) selected=i;
        open_dropdown(sx::i18n::tr("Subtitle colour"), {sx::i18n::tr("White"),sx::i18n::tr("Yellow"),sx::i18n::tr("Cyan")}, selected, [this](int i) {
            if(i<0 || i>=3) return;
            prefs_.subtitle_style.colour=values[i]; save_prefs(); refresh_settings(); cue(hui::audio::Cue::saved);
        }); break;
    }
    case kSubEffect: {
        static constexpr int values[] = {0,1,2};
        int selected=0; for(int i=0;i<3;++i) if(prefs_.subtitle_style.effect==values[i]) selected=i;
        open_dropdown(sx::i18n::tr("Subtitle effect"), {sx::i18n::tr("Plain"),sx::i18n::tr("Outline"),sx::i18n::tr("Shadow")}, selected, [this](int i) {
            if(i<0 || i>=3) return;
            prefs_.subtitle_style.effect=values[i]; save_prefs(); refresh_settings(); cue(hui::audio::Cue::saved);
        }); break;
    }
    case kSubBackground: {
        static constexpr int values[] = {0,25,50,75,100};
        int selected=0; for(int i=0;i<5;++i) if(prefs_.subtitle_style.background==values[i]) selected=i;
        open_dropdown(sx::i18n::tr("Subtitle background"), {sx::i18n::tr("Off"),"25%","50%","75%","100%"}, selected, [this](int i) {
            if(i<0 || i>=5) return;
            prefs_.subtitle_style.background=values[i]; save_prefs(); refresh_settings(); cue(hui::audio::Cue::saved);
        }); break;
    }
    case kSeek: {
        static constexpr int values[] = {5,10,15,30,60};
        int selected=0; for(int i=0;i<5;++i) if(prefs_.seek_seconds==values[i]) selected=i;
        open_dropdown(sx::i18n::tr("D-pad seek interval"), {"5 s","10 s","15 s","30 s","60 s"}, selected, [this](int i) {
            if(i<0 || i>=5) return;
            prefs_.seek_seconds=values[i]; save_prefs(); refresh_settings(); cue(hui::audio::Cue::saved);
        }); break;
    }
    case kShoulderSeek: {
        static constexpr int values[] = {5,10,30,60,120,300};
        int selected=0; for(int i=0;i<6;++i) if(prefs_.shoulder_seek_seconds==values[i]) selected=i;
        open_dropdown(sx::i18n::tr("L1 / R1 seek interval"), {"5 s","10 s","30 s","60 s","120 s","300 s"}, selected, [this](int i) {
            if(i<0 || i>=6) return;
            prefs_.shoulder_seek_seconds=values[i]; save_prefs(); refresh_settings(); cue(hui::audio::Cue::saved);
        }); break;
    }
    case kCountdown: {
        static constexpr int values[] = {5,10,15,30,60,120};
        int selected=0; for(int i=0;i<6;++i) if(prefs_.next_episode_seconds==values[i]) selected=i;
        open_dropdown(sx::i18n::tr("Next-episode countdown"), {"5 s","10 s","15 s","30 s","60 s","120 s"}, selected, [this](int i) {
            if(i<0 || i>=6) return;
            prefs_.next_episode_seconds=values[i]; save_prefs(); refresh_settings(); cue(hui::audio::Cue::saved);
        }); break;
    }
    case kReducedMotion: prefs_.reduced_motion=!prefs_.reduced_motion; save_prefs(); cue(hui::audio::Cue::toggle); break;
    case kHighContrast: prefs_.high_contrast=!prefs_.high_contrast; save_prefs(); cue(hui::audio::Cue::toggle); break;
    case kSubtitleAutoSync: prefs_.subtitle_auto_sync=!prefs_.subtitle_auto_sync;save_prefs();refresh_settings();break;
    case kTrailerLanguage: {
        const std::vector<std::string> ids{"","en","es","fr","de","it","pt","nl","pl","tr","ar","he","ja","ko","zh","hi","ru","uk","el","cs","sv","da","fi","ro","hu","vi","th","id"};
        std::vector<std::string> labels;int active=0;for(size_t n=0;n<ids.size();++n){labels.push_back(ids[n].empty()?sx::i18n::tr("Follow preferred languages"):i18n::tr(language_name(ids[n])));if(ids[n]==prefs_.trailer_language)active=int(n);}
        open_dropdown(sx::i18n::tr("Trailer language"),labels,active,[this,ids](int n){if(n<0 || n>=int(ids.size()))return;prefs_.trailer_language=ids[n];save_prefs();refresh_settings();});break;
    }
    case kChapterSkip: prefs_.chapter_skip_segments=!prefs_.chapter_skip_segments;save_prefs();refresh_settings();break;
    case kNightMode:
        open_dropdown(sx::i18n::tr("Night Mode"), {sx::i18n::tr("Off (default)"),sx::i18n::tr("Light"),sx::i18n::tr("Medium"),sx::i18n::tr("Strong")}, prefs_.night_mode, [this](int i){if(i<0 || i>3)return;prefs_.night_mode=i;save_prefs();refresh_settings();});break;
    case kLfeMix:
        open_dropdown(sx::i18n::tr("Bass in stereo downmix"), {sx::i18n::tr("Off"),"50% (default)","100%"},prefs_.lfe_mix_percent/50,[this](int i){if(i<0 || i>2)return;prefs_.lfe_mix_percent=i*50;save_prefs();refresh_settings();});break;
    case kAudioGain: {
        std::vector<std::string> labels;for(int v=50;v<=300;v+=25)labels.push_back(std::to_string(v)+"%");
        open_dropdown(sx::i18n::tr("Audio volume / boost"),labels,(prefs_.audio_gain_percent-50)/25,[this](int i){prefs_.audio_gain_percent=50+i*25;save_prefs();refresh_settings();});break;
    }
    case kAudioDelay:
    case kSubtitleDelay: {
        const bool audio=row==kAudioDelay;const int limit=audio?2000:10000;
        std::vector<std::string> labels;for(int v=-limit;v<=limit;v+=50)labels.push_back(std::to_string(v)+" ms");
        open_dropdown(audio?sx::i18n::tr("Audio sync delay"):sx::i18n::tr("Subtitle sync delay"),labels,((audio?prefs_.audio_delay_ms:prefs_.subtitle_delay_ms)+limit)/50,[this,audio,limit](int i){
            if(audio)prefs_.audio_delay_ms=-limit+i*50;else prefs_.subtitle_delay_ms=-limit+i*50;save_prefs();refresh_settings();});break;
    }
    case kAudioMode: {
        const int active=prefs_.audio_output_mode=="pcm"?0:prefs_.audio_output_mode=="auto"?1:2;
        open_dropdown(sx::i18n::tr("Audio output"),{"PCM",sx::i18n::tr("Auto (experimental)"),sx::i18n::tr("Bitstream (experimental)")},active,[this](int i){
            prefs_.audio_output_mode=i==0?"pcm":i==1?"auto":"bitstream";save_prefs();refresh_settings();});
        dropdown.message=sx::i18n::tr("Auto uses only formats advertised by the HDMI receiver. Bitstream tries a compressed port even if capability detection is unavailable. Refused ports fall back to PCM. TrueHD and DTS-HD keep decoded lossless PCM.");break;
    }
    case kDonation: {
        sign_in=SignInState{};sign_in.link_only=true;sign_in.donation=true;sign_in.title=sx::i18n::tr("Support on Ko-fi");
        sign_in.link=donation_link;sign_in.cancel_label=sx::i18n::tr("Close");
        std::uint8_t temp[qrcodegen_BUFFER_LEN_MAX],qr[qrcodegen_BUFFER_LEN_MAX];
        if(qrcodegen_encodeText(donation_url,temp,qr,qrcodegen_Ecc_MEDIUM,qrcodegen_VERSION_MIN,20,qrcodegen_Mask_AUTO,true)) {
            sign_in.qr_size=qrcodegen_getSize(qr);sign_in.qr_modules.resize(sign_in.qr_size*sign_in.qr_size);
            for(int y=0;y<sign_in.qr_size;++y)for(int x=0;x<sign_in.qr_size;++x)
                sign_in.qr_modules[y*sign_in.qr_size+x]=qrcodegen_getModule(qr,x,y);
        }
        sign_in_open=true;break;
    }
    case kMetadataCredits:
        open_dropdown(sx::i18n::tr("Metadata credits"),{sx::i18n::tr("Close")},0,[](int){});
        dropdown.message="This product uses the TMDB API but is not endorsed or certified by TMDB. Movie and TV metadata: https://www.themoviedb.org/ Optional episode ordering: https://thetvdb.com/ through your own licensed API access.";
        break;
    case kInstallSource: install_source_menu(); break;
    case kReleaseNotes: release_notes_open=true; release_notes_version=nuvio_update::current_version; break;
    case kDiagnostics: diagnostic_menu();break;
    case kAudioLangs:
        ask_text([this](const std::string &v) {
            if (trim(v).empty())
                return;
            prefs_.audio_langs = trim(v) == "-" ? "" : trim(v);
            save_prefs();
            cue(hui::audio::Cue::saved);
            refresh_settings();
        });
        break;
    case kAddAddon:
        ask_text([this](const std::string &v) {
            const std::string url = normalize_addon_url(v);
            if (trim(v).empty() || trim(v) == "https://")
                return;
            say(sx::i18n::tr("Loading addon or plugin repository..."));
            bg<std::string>(
                [url]() {
                    ::Addon a;
                    std::string err;
                    if (!fetch_addon(url, a, err))
                        return sx::i18n::tr("Could not add the addon or plugin: ") + err;
                    return a.provider_repository ? std::string("plugin") : std::string("addon");
                },
                [this, url](std::string &err) {
                    if (err != "plugin" && err != "addon")
                    {
                        say(err, 6.0, true);
                        return;
                    }
                    const bool plugin = err == "plugin";
                    if (plugin ? inherit_plugins_ : inherit_addons_) {
                        say(sx::i18n::tr("This profile inherits those sources. Switch to the primary profile to edit them."), 8.0); return;
                    }
                    if (std::find(prefs_.extra_addons.begin(), prefs_.extra_addons.end(), url) == prefs_.extra_addons.end())
                        prefs_.extra_addons.push_back(url);
                    save_prefs();
                    sync_source(url, plugin, false);
                    say(sx::i18n::tr("Added. Open Addons to manage it and enable individual providers."), 7.0);
                    load_addons();
                    refresh_settings();
                });
        });
        break;
    case kAudioOutput:
        prefs_.surround_audio = !prefs_.surround_audio; save_prefs(); cue(hui::audio::Cue::toggle); break;
    case kAutoSubs:
        prefs_.auto_subtitles = !prefs_.auto_subtitles;
        save_prefs();
        cue(hui::audio::Cue::toggle);
        break;
    case kSubSize:
    {
        const int cur = subtitle_size::index(prefs_.sub_size);
        std::vector<std::string> sizes;for(const char* label:subtitle_size::labels)sizes.emplace_back(i18n::tr(label));
        open_dropdown(sx::i18n::tr("Subtitle size"), sizes, cur, [this](int i) {
            if (i<0 || i>=int(subtitle_size::ids.size())) return;
            prefs_.sub_size = subtitle_size::ids[i];
            save_prefs();
            cue(hui::audio::Cue::saved);
            refresh_settings();
        });
        break;
    }
    case kAutoplay:
        prefs_.autoplay_next = !prefs_.autoplay_next;
        save_prefs();
        cue(hui::audio::Cue::toggle);
        break;
    case kSkipSegments:
        prefs_.skip_segments = !prefs_.skip_segments;
        save_prefs();
        cue(hui::audio::Cue::toggle);
        break;
    case kUiSounds:
        prefs_.ui_sounds = !prefs_.ui_sounds;
        save_prefs();
        cue(hui::audio::Cue::toggle);
        break;
    case kCalmBackgrounds:
        prefs_.calm_backgrounds = !prefs_.calm_backgrounds;
        save_prefs();
        cue(hui::audio::Cue::toggle);
        break;
    case kReload:
        addons_reload();
        break;
    case kUpdates:
        update_menu();
        break;
    case kExit:
        exit_ = true;
        break;
    default:
        break;
    }
    refresh_settings();
}

// ---------------------------------------------------------------------------
// Pop-ups

void Session::say(const std::string &message, double seconds, bool error)
{
    toast.message = message;
    toast.error = error;
    toast_open = true;
    cue(hui::audio::Cue::notify);
    toast_until_ = now_seconds() + seconds;
}

void Session::open_dropdown(const std::string &title, const std::vector<std::string> &options, int active,
                            std::function<void(int)> chosen)
{
    remote_capture_until_=0; // Replacing a dialog cancels button learning.
    update_dialog_ = false;
    install_source_dialog_ = false;
    dropdown.title = title;
    dropdown.purpose=DropdownState::Purpose::generic;
    dropdown.message.clear();
    dropdown.checked.clear();
    dropdown.wide=false;
    dropdown.danger = -1;
    dropdown.dialog = false;
    dropdown.poster = 0;
    dropdown.progress = -1.0f;
    dropdown.options = options;
    dropdown.active = active;
    dropdown.selected = std::max(0, std::min(active, static_cast<int>(options.size()) - 1));
    dropdown_chosen_ = std::move(chosen);
    dropdown_open = true;
}

void Session::dropdown_confirm()
{
    update_dialog_ = false;
    dropdown_open = false;
    const auto fn = dropdown_chosen_;
    dropdown_chosen_ = nullptr;
    if (fn && dropdown.selected >= 0 && dropdown.selected < static_cast<int>(dropdown.options.size()))
        fn(dropdown.selected);
}

void Session::release_notes_dismiss() {
    release_notes_open=false; prefs_.seen_release=release_notes_version; save_prefs();
    if(login_after_notes_ && !prefs_.install_source.empty()) { login_after_notes_=false; login_start(); }
}

void Session::dropdown_cancel()
{
    if((dropdown.purpose==DropdownState::Purpose::usb_import || dropdown.purpose==DropdownState::Purpose::usb_scan) && live_usb_cancel_)*live_usb_cancel_=true;
    if(install_source_dialog_ && install_source_first_) {
        dropdown_open=false; dropdown_chosen_=nullptr;
        install_source_choose(2);
        return;
    }
    install_source_dialog_=false;
    if (update_dialog_) updater_.cancel();
    update_dialog_ = false;
    dropdown_open = false;
    dropdown_chosen_ = nullptr;
}

// ---------------------------------------------------------------------------
// Signing in with a code approved on another device

void Session::login_start()
{
    if (device_cancel_) *device_cancel_ = true;
    device_provider_.clear();
    const int gen = ++login_gen_;
    sign_in_open = true;
    sign_in = SignInState();
    sign_in.link = "nuvio.tv/link";
    sign_in.status = sx::i18n::tr("Loading...");
    login_code_raw_.clear();
    login_qr_url_.clear();
    login_polling_ = false;
    bg<LinkCode>([]() { return link_create(); },
                 [this, gen](LinkCode &lc) {
                     if (gen != login_gen_ || !sign_in_open)
                         return;
                     if (!lc.ok)
                     {
                         sign_in.status = sx::i18n::tr("Could not get a code: ") + lc.error;
                         return;
                     }
                     login_code_raw_ = lc.code;
                     sign_in.code = lc.display_code;
                     std::string shown = lc.verification_uri;
                     if (starts_with(shown, "https://"))
                         shown = shown.substr(8);
                     sign_in.link = shown;
                     std::uint8_t temp[qrcodegen_BUFFER_LEN_MAX], qr[qrcodegen_BUFFER_LEN_MAX];
                     if (qrcodegen_encodeText(lc.link.c_str(), temp, qr, qrcodegen_Ecc_MEDIUM,
                         qrcodegen_VERSION_MIN, 20, qrcodegen_Mask_AUTO, true))
                     {
                         sign_in.qr_size = qrcodegen_getSize(qr);
                         sign_in.qr_modules.resize(sign_in.qr_size * sign_in.qr_size);
                         for (int y = 0; y < sign_in.qr_size; ++y)
                             for (int x = 0; x < sign_in.qr_size; ++x)
                                 sign_in.qr_modules[y * sign_in.qr_size + x] = qrcodegen_getModule(qr, x, y);
                     }
                     else
                         say(sx::i18n::tr("Use the displayed address and code to sign in"), 6.0);
                     sign_in.status = sx::i18n::tr("Waiting for approval on your phone...");
                     login_interval_ = lc.poll_interval;
                     login_next_poll_ = now_seconds() + login_interval_;
                     login_expires_ = now_seconds() + lc.expires_in;
                 });
}

void Session::login_poll()
{
    if (login_code_raw_.empty() || login_polling_ || now_seconds() < login_next_poll_)
        return;
    if (now_seconds() > login_expires_)
    {
        sign_in.status = sx::i18n::tr("Sign-in timed out. Get a fresh code from Settings.");
        login_code_raw_.clear();
        return;
    }
    login_polling_ = true;
    const int gen = login_gen_;
    const std::string code = login_code_raw_;
    bg<ApiResult>([code]() { return link_read(code); },
                  [this, gen](ApiResult &r) {
                      if (gen != login_gen_ || !sign_in_open)
                          return;
                      login_polling_ = false;
                      login_next_poll_ = now_seconds() + login_interval_;
                      if (r.ok)
                          login_done(jstr(r.result, "authKey"));
                      else if (!r.error.empty())
                          sign_in.status = r.error;
                      if (jbool(r.result, "terminal"))
                      {
                          login_code_raw_.clear();
                          nuvio_pairing_cancel();
                      }
                  });
}

void Session::sign_in_cancel()
{
    if(sign_in.link_only) {if(torrent_drop_open_){bt::Engine::get().stop_web_drop();torrent_drop_open_=false;}sign_in_open=false;return;}
    ++login_gen_;
    nuvio_pairing_cancel();
    sign_in_open = false;
    login_code_raw_.clear();
    if (device_cancel_) *device_cancel_ = true;
    if (!device_provider_.empty()) {
        if (starts_with(device_provider_,"tracking:")) {
            const auto key=prefs_.auth_key, p=device_provider_.substr(9);
            bg<ApiResult>([key,p]{return api_tracking(key,"device_cancel",{{"provider",p}});},[](auto&){});
        }
        if(device_provider_=="plex")media_plex_cancel();
        device_provider_.clear(); device_code_ = {}; return;
    }
    prefs_.onboarding_done = true;
    save_prefs();
}

void Session::login_done(const std::string &auth_key)
{
    sign_in_cancel();
    save_progress(); save_profile_settings();
    clear_profile_views();
    profile_ready_ = false;
    prefs_.auth_key = auth_key;
    prefs_.user_email.clear();
    save_prefs();
    say(sx::i18n::tr("Signed in"));
    bg<ApiResult>([auth_key]() { return api_get_user(auth_key); },
                  [this](ApiResult &r) {
                      if (!r.ok)
                          return;
                      prefs_.user_email = jstr(r.result, "email");
                      save_prefs();
                      refresh_settings();
                      say(sx::i18n::tr("Signed in as ") + prefs_.user_email);
                  });
    profile_ready_ = false;
    profiles_loading_ = false;
    profile_prompt_pending_ = true;
    board.status = sx::i18n::tr("Choose a Nuvio profile to load your catalogs and history.");
    refresh_library(); refresh_addons(); refresh_settings();
}

void Session::sign_out()
{
    if (watching || resuming_) { say(sx::i18n::tr("Stop playback before signing out"), 6.0); return; }
    const std::string key = prefs_.auth_key;
    bg<ApiResult>([key]() { return api_logout(key); }, [this](ApiResult& r) {
        if (!r.ok) { say(r.error, 8.0, true); return; }
        save_progress(); save_profile_settings();
        prefs_.auth_key.clear(); prefs_.user_email.clear();
        profile_apply(json{{"path", data_dir_ + "/guest"}, {"authKey", ""}, {"profile", json{{"name", "Guest"}}}});
        ++login_gen_;
        save_prefs();
        say(sx::i18n::tr("Signed out"));
    });

}

// ---------------------------------------------------------------------------
// Frame

void Session::update(float dt, const Cursor &cursor)
{
    (void)dt;
    g_tasks.drain();
    provider_tasks_.drain();
    torrent_poll_drop();
    remote_capture_tick();
    update_status();
    if (signed_in() && !nuvio_account_saved())
    {
        if (watching) watch_stop(false);
        save_progress(); save_profile_settings();
        prefs_.auth_key.clear(); prefs_.user_email.clear();
        profile_apply(json{{"path", data_dir_ + "/guest"}, {"authKey", ""}, {"profile", json{{"name", "Guest"}}}});
        save_prefs(); refresh_settings();
        say(sx::i18n::tr("Your Nuvio session expired. Sign in again in Settings."), 8.0, true);
    }
    if (profile_prompt_pending_ && !typing() && !release_notes_open && !dropdown_open && !sign_in_open && !install_source_dialog_) {
        profile_prompt_pending_ = false; profiles_menu(true);
    }
    const double now = now_seconds();
    if (boot_done_ && signed_in() && !watching && !library_loading_ && now >= library_refresh_at_)
        load_library();
    // While the first screen is being got ready, more pictures go up to the GPU each frame.
    const bool arrived = tex_.pump(boot_done_ ? 3 : 12);

    if (now - clock_ > 1.0)
    {
        clock_ = now;
        clock = format_clock();
    }
    if (!boot_done_ && boot_check(now - boot_start_))
    {
        boot_done_ = true;
        dlog("boot: ready after %.1f s", now - boot_start_);
    }
    integrity_maybe_warn();
    if (toast_open && now > toast_until_)
        toast_open = false;
    // Played from Continue Watching on the Board: the title's page was open behind it only to play.
    // When the video is over (and no next episode is lined up), it closes.
    if (resumed_from_board_ && !watching && !resuming_ && !autoplay_pending_)
    {
        resumed_from_board_ = false;
        close_detail();
    }
    if (sign_in_open && !sign_in.link_only) {
        if (device_provider_.empty()) login_poll();
        else if (device_provider_=="plex")media_plex_poll();
        else if(device_provider_=="drive")backup_drive_poll();
        else if (starts_with(device_provider_, "tracking:")) tracker_login_poll();
        else service_login_poll();
    }
    poll_typing();
    search_suggestions_tick();
    live_refresh_tick();
    media_flush_auth();
    live_guide_update(cursor.live);
    sports_tick(cursor.sports);
    if(page_==Page::library && now>=series_updates_tick_){series_updates_tick_=now+60;refresh_library();}
    if (watching)
    {
        watch_update();
        upload_video();
    }

    detail_preparation_update(cursor);

    // More of Discover when the cursor nears the end.
    constexpr int kDiscoverCols = 4;
    if (!disc_end_ && !disc_loading_ && !disc_items_.empty() &&
        cursor.discover + 2 * kDiscoverCols >= static_cast<int>(disc_items_.size()))
        discover_load(true);

    const bool moved = cursor.board_row != last_cursor_.board_row || cursor.board_col != last_cursor_.board_col ||
                       cursor.discover != last_cursor_.discover || cursor.library != last_cursor_.library || cursor.iptv != last_cursor_.iptv ||
                       cursor.episode != last_cursor_.episode || cursor.search_row != last_cursor_.search_row ||
                       cursor.search_col != last_cursor_.search_col;
    last_cursor_ = cursor;
    if (arrived || moved || art_dirty_ || now - last_art_ > 1.0)
    {
        art_dirty_ = false;
        last_art_ = now;
        refresh_art(cursor);
    }
    if (tex_.trim(kTextureBudget))
        refresh_art(cursor);
}

// The app is ready to be shown when the Board has its rows and the first screen's pictures are on the
// GPU: the cards in the first two rows and the picture behind the first title. It does not wait for
// ever for what does not come: a catalog that never answers, a picture that cannot be fetched.
bool Session::boot_check(double t) const
{
    if (t > 10.0)
        return true;
    if (t < 1.8)
        return false; // the mark has its moment
    const bool answered = !addons_loading_ && !board_loading_;
    const std::size_t rows = board.rows.size();
    if (rows == 0)
        return answered; // nothing to wait for: the page tells what is wrong
    if (!answered && rows < 3)
        return false;
    if (t > 7.0)
        return true; // pictures that have not come by now come when they come
    for (std::size_t r = 0; r < rows && r < 2; ++r)
    {
        const std::vector<Item> &items = board_[static_cast<std::size_t>(board_map_[r])].items;
        for (std::size_t c = 0; c < items.size() && c < board.rows[r].items.size() && c < 8; ++c)
            if (!items[c].poster.empty() && board.rows[r].items[c].poster == 0)
                return false;
    }
    const Item &first = board_[static_cast<std::size_t>(board_map_[0])].items.front();
    if (!first.background.empty())
        return board.rows[0].items.front().backdrop != 0;
    // No picture yet: the addons are being asked for it.
    return !(meta_asked_.count(first.type + ":" + first.id) && !meta_cache_.count(first.type + ":" + first.id));
}

// ---------------------------------------------------------------------------
// Artwork: the textures for what is near the cursor; the rest only if they are
// already on the GPU.

void Session::refresh_art(const Cursor &cursor)
{
    const auto fetch = [&](const std::string &url, ArtKind kind, bool near) {
        return near ? tex_.get(url, kind) : tex_.peek(url, kind);
    };

    // Board: cards around the cursor, and the hero's picture for the focused title and its neighbours.
    for (std::size_t r = 0; r < board.rows.size() && r < board_map_.size(); ++r)
    {
        const std::vector<Item> &items = board_[static_cast<std::size_t>(board_map_[r])].items;
        const bool row_near = std::abs(static_cast<int>(r) - cursor.board_row) <= 2;
        for (std::size_t c = 0; c < board.rows[r].items.size() && c < items.size(); ++c)
        {
            Title &t = board.rows[r].items[c];
            const int col = static_cast<int>(c);
            t.poster = fetch(items[c].poster, ArtKind::poster, row_near && col < cursor.board_col + 12);
            const bool hero = static_cast<int>(r) == cursor.board_row && std::abs(col - cursor.board_col) <= 1;
            t.backdrop = fetch(items[c].background, ArtKind::backdrop, hero);
            // The library lists a title without its backdrop or story: ask the addons.
            if ((hero && (items[c].background.empty() || items[c].description.empty())) ||
                (row_near && col < cursor.board_col + 12 && (items[c].name.empty() || items[c].name == "Untitled")))
                want_meta(items[c]);
        }
    }

    // Search results: the same, without a hero.
    for (std::size_t r = 0; r < search.rows.size() && r < search_map_.size(); ++r)
    {
        const std::vector<Item> &items = search_[static_cast<std::size_t>(search_map_[r])].items;
        const bool row_near = std::abs(static_cast<int>(r) - cursor.search_row) <= 2;
        for (std::size_t c = 0; c < search.rows[r].items.size() && c < items.size(); ++c)
            search.rows[r].items[c].poster =
                fetch(items[c].poster, ArtKind::poster, row_near && static_cast<int>(c) < cursor.search_col + 12);
    }

    // Starting a stream: the title's picture behind the ring and in it.
    if (launch_open)
    {
        launch.backdrop = fetch(w_item_.background, ArtKind::backdrop, true);
        launch.poster = fetch(w_item_.poster, ArtKind::poster, true);
    }

    // Discover: posters in a window, and the preview picture of the focused title.
    for (std::size_t i = 0; i < discover.items.size() && i < disc_items_.size(); ++i)
    {
        Title &t = discover.items[i];
        const int d = static_cast<int>(i) - cursor.discover;
        t.poster = fetch(disc_items_[i].poster, ArtKind::poster, d > -12 && d < 24);
        t.backdrop = fetch(disc_items_[i].background, ArtKind::backdrop, d == 0);
    }

    // Library
    for (std::size_t i = 0; i < library.items.size() && i < lib_items_.size(); ++i)
    {
        const int d = static_cast<int>(i) - cursor.library;
        const bool near = d > -14 && d < 28;
        // Tracker watchlists often carry IDs but no poster. Resolve visible
        // cards independently of Board/Continue Watching, with bounded work.
        if (page_ == Page::library && near && lib_items_[i].poster.empty())
            want_meta(lib_items_[i]);
        if (page_ == Page::library && d>=-4 && d<8) want_series_updates(lib_items_[i]);
        library.items[i].poster = fetch(lib_items_[i].poster, ArtKind::poster, near);
    }

    // IPTV artwork stays on its own page; these IDs never ask addon metadata.
    if(page_==Page::iptv)for(size_t i=0;i<iptv_content.items.size()&&i<iptv_indices_.size();++i){
        const auto& e=iptv_catalog_.entries[iptv_indices_[i]];
        const auto& image=e.poster.empty()?iptv_series_poster_:e.poster;
        int d=int(i)-cursor.iptv;
        iptv_content.items[i].poster=fetch(image,ArtKind::poster,d>-14&&d<28);
    }

    if(page_==Page::servers && media_account_<media_accounts_.size())for(size_t i=0;i<media_content.items.size()&&i<media_items_.size();++i){
        int d=int(i)-cursor.media;
        media_content.items[i].poster=fetch("media-art:"+media_accounts_[media_account_].id+":"+jstr(media_items_[i],"Id"),ArtKind::poster,d>-14&&d<28);
    }

    // Addons
    for (std::size_t i = 0; i < addons.items.size() && i < addon_logos_.size(); ++i)
        addons.items[i].logo = fetch(addon_logos_[i], ArtKind::icon, true);

    // A title's page
    if (d_open_)
    {
        const std::string &background = d_meta_loaded_ && !d_meta_.background.empty() ? d_meta_.background : d_item_.background;
        detail.title.backdrop = fetch(background, ArtKind::backdrop, true);
        const std::string &poster = d_meta_loaded_ && !d_meta_.poster.empty() ? d_meta_.poster : d_item_.poster;
        detail.title.poster = fetch(poster, ArtKind::poster, !detail.series);
        for(size_t i=0;i<detail.people.size();++i)detail.people[i].photo=fetch(detail.people[i].photo_url,ArtKind::poster,std::abs(int(i)-cursor.cast)<8);
        for (std::size_t i = 0; i < detail.episodes.size() && i < d_season_videos_.size(); ++i)
            detail.episodes[i].thumb = fetch(d_season_videos_[i]->thumbnail.empty() ? background : d_season_videos_[i]->thumbnail, ArtKind::thumb,
                                             std::abs(static_cast<int>(i) - cursor.episode) < 10);
    }
    if(person_open){
        person.photo=fetch(person.data.photo,ArtKind::poster,true);
        person.movies.resize(person.data.movies.size());person.series.resize(person.data.series.size());
        for(size_t i=0;i<person.movies.size();++i)person.movies[i]=fetch(person.data.movies[i].poster,ArtKind::poster,std::abs(int(i)-cursor.person_movie)<8);
        for(size_t i=0;i<person.series.size();++i)person.series[i]=fetch(person.data.series[i].poster,ArtKind::poster,std::abs(int(i)-cursor.person_series)<8);
    }
}

} // namespace sx
