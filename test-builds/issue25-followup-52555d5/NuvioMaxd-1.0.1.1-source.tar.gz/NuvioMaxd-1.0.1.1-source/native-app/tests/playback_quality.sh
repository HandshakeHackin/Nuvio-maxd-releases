#!/usr/bin/env bash
set -euo pipefail
ROOT=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)
source "$ROOT/tests/host_libass.sh"
mkdir -p "$ROOT/test-output"
read -r -a cflags <<< "${HOST_QUALITY_CFLAGS:-$(pkg-config --cflags libavformat libavcodec libavutil libass fribidi)}"
read -r -a libs <<< "${HOST_QUALITY_LIBS:-$(pkg-config --libs libavformat libavcodec libavutil libass fribidi libcurl)}"
${HOST_CXX:-g++} -std=c++20 -O0 -g -Wall -Wextra -Werror -pthread -DPLATFORM_PS5_NATIVE=1 -DNUVIO_SUBTITLE_TEST_HOOK=1 -DHAVE_FRIBIDI \
    -I"$ROOT/src" -I"$ROOT/third_party" -I"$NUVIO_HOST_LIBASS_INCLUDE" "${cflags[@]}" \
    "$ROOT/tests/playback_quality_host.cpp" "$ROOT/src/pcm_out.cpp" "$ROOT/src/bitstream.cpp" "$ROOT/src/packet_storage.cpp" \
    "$ROOT/src/subtitle_renderer.cpp" "$ROOT/src/subtitles.cpp" "$ROOT/src/video_frame.cpp" "$ROOT/src/util.cpp" "$ROOT/src/bidi.cpp" \
    -L"$NUVIO_HOST_LIBASS_LIBDIR" "${libs[@]}" -o "$ROOT/test-output/playback-quality-host"
"$ROOT/test-output/playback-quality-host" "$ROOT/app/fonts"
