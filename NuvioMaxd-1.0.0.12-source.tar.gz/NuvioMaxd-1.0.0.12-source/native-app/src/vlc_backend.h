// Optional libVLC engine; no VLC types cross the application boundary.
// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
#include "video_frame.h"
#include "chapters.hpp"
#include <memory>
#include <string>
#include <utility>
#include <vector>
class VlcBackend {
  public:
    struct Options {
        std::string url;
        std::vector<std::string> headers, audio_languages;
        double start = 0;
        bool surround = false, paused = false, software = false;
        int audio = -1, subtitle = -2;
        double subtitle_delay = 0;
        int gain_percent=100;
        int night_mode=0;
        double audio_delay=0;
    };
    struct Track {
        int stream = -1;
        std::string label, lang;
        bool is_default = false;
    };
    static bool available();
    static void prepare();
    VlcBackend();
    ~VlcBackend();
    bool open(const Options &);
    void close();
    int state() const; // Player::State values, without sharing Player's implementation
    std::string error() const;
    bool paused() const;
    void set_paused(bool);
    bool buffering(int *percent = nullptr) const;
    double position() const;
    double duration() const;
    void seek(double);
    std::vector<playback::Chapter> chapters() const;
    uint32_t revision() const {return revision_;}
    const VideoPicture *present();
    int serial() const;
    int picture_serial() const;
    std::vector<Track> tracks(bool subtitles) const;
    int audio_stream() const;
    void select_audio(int);
    void set_audio_gain(int);
    void set_audio_delay(double);
    void select_subtitle(int, double delay);
    std::string audio_output() const;
    std::string codec_summary() const;
    std::pair<std::string,std::string> diagnostic_codecs() const;
    std::string stats() const;
    void log_stats();

  private:
    uint32_t revision_=0;
    struct Impl;
    std::unique_ptr<Impl> d_;
};
